#pragma GCC optimize(3)
#include "RefinedMain.h"



#ifdef KPri
string Ff = "Kfirst";
string Ff1 = "K";
#endif
#ifdef RPri
string Ff = "Rfirst";
string Ff1 = "R";
#endif

#ifdef WP
string outfilename = "C:\\Users\\Root\\Desktop\\TDKEʵ��\\Query\\ExperimentData\\" + Ff + "\\WP\\WP_" + Ff1 + "_Case";
string infilename = "C:\\Users\\Root\\Desktop\\TDKEʵ��\\Query\\WP\\WP_Case";
#endif
#ifdef BK
string outfilename = "C:\\Users\\Root\\Desktop\\TDKEʵ��\\Query\\ExperimentData\\" + Ff + "\\BK\\BK_" + Ff1 + "_Case";
string infilename = "C:\\Users\\Root\\Desktop\\TDKEʵ��\\Query\\BK\\BK_Case";
#endif
#ifdef GW
string outfilename = "C:\\Users\\Root\\Desktop\\TDKEʵ��\\Query\\ExperimentData\\" + Ff + "\\GW\\GW_" + Ff1 + "_Case";
string infilename = "C:\\Users\\Root\\Desktop\\TDKEʵ��\\Query\\GW\\GW_Case";
#endif
#ifdef FK
string outfilename = "C:\\Users\\Root\\Desktop\\TDKEʵ��\\Query\\ExperimentData\\" + Ff + "\\FK\\FK_" + Ff1 + "_Case";
string infilename = "C:\\Users\\Root\\Desktop\\TDKEʵ��\\Query\\FK\\FK_Case";
#endif
#ifdef FS
string outfilename = "C:\\Users\\Root\\Desktop\\TDKEʵ��\\Query\\ExperimentData\\" + Ff + "\\FS\\FS_" + Ff1 + "_Case";
string infilename = "C:\\Users\\Root\\Desktop\\TDKEʵ��\\Query\\FS\\FS_Case";
#endif


struct Query {
	unsigned q;
	unsigned k;
	float r;
	vector<unsigned> w;
};
void ReadQuery(string Filename, vector<Query>& Querys);

void main()
{
	string Filename;
	unsigned length;
	cout << "Please input the filename: " << endl;
	cin >> Filename;
	cout << "Please input the filelength: " << endl;
	cin >> length;
	unsigned Height = 0;
	cout << "please input the Height of the quadtree: " << endl;
	cin >> Height;

	ReadData Datas;
	auto Read = high_resolution_clock::now();
	Datas.ReadDataset(Filename, FILELENGTH);
	CandidateGk.reserve(length/5);

	unsigned fileid = 0;
	while (fileid++ != 5)
	{
		Filename = outfilename + to_string(fileid) + ".csv";
		ifstream intime;
		intime.open(Filename, ios::in);
		if (!intime.is_open())
		{
			cout << "open" << Filename << "error" << endl;
			exit(0);
		}
		string time1;
		vector<string> time2;
		while (getline(intime, time1))
		{
			time2.push_back(time1);
		}
		intime.close();

		ofstream outTime;
		outTime.open(Filename, ios::out);

#ifdef KPri
		outTime << "q,m,k,r,Justktime,JustRtime,MixCandiTime,PenaltyVarifyTime,AllMixTime,Peanlty(mix),Peanlty(k),Peanlty(r),bestPair(k'_r),bestPair(k_r'),bestPair(k'_r')" << endl; // Kfi
#endif
#ifdef RPri
		outTime << "q,m,k,r,Justktime,JustRtime,MixCandiTime,PenaltyVarifyTime,AllMixTime,Peanlty(mix),bestPair(k'_r')" << endl; //Rfi
#endif
		/*
		for (auto& a : time2)
		{
			outTime << a << endl;
		}*/
		Filename = infilename + to_string(fileid) + ".txt";
		vector<Query> Querys;
		ReadQuery(Filename, Querys);



		auto TreeCoreIndexbegin = high_resolution_clock::now();


		unsigned countquery = 0;
		unsigned countw = 0;

		for (auto& [q, k, r, w] : Querys)
		{
			cout << "Location of Querys is " << countquery++ << endl;
			if (find(w.begin(), w.end(), q) != w.end())
			{
				continue;
			}

			for (auto& m : w)
			{

				cout << "Missing is " << m << "  q is " << q << endl;
				//cout << "BEGIN RUNING" << endl;
				auto start = high_resolution_clock::now();


				float rBound[] = { 0,0 };
				unsigned kBound[] = { 0,0 };
				//rmin = max(distance(q,m),r)
				float rminmin = std::min(std::hypot(Datas.GetGraphG_Location()[q].first - Datas.GetGraphG_Location()[m].first,
					Datas.GetGraphG_Location()[q].second - Datas.GetGraphG_Location()[m].second) / 2.0, double(r));
				rBound[0] = std::max(std::hypot(Datas.GetGraphG_Location()[q].first - Datas.GetGraphG_Location()[m].first,
					Datas.GetGraphG_Location()[q].second - Datas.GetGraphG_Location()[m].second) / 2.0, double(r));
				kBound[1] = std::min(unsigned(Datas.GetL_Degree()[m]), k);

				//kmax = min(coreG(m),k)
				//The upper bound of k'
				//kBound[0] = JustK_NoLeverIndex(Datas, q, m, 1, rBound[0], Height);
				auto Justkb = high_resolution_clock::now();
				if (fileid == 4 || fileid == 5)
				{
					kBound[0] = JustK_HaveLeverIndex45(Datas, q, m, 1, rBound[0], Height);
				}
				else
				{
					kBound[0] = JustK_HaveLeverIndex(Datas, q, m, 1, rBound[0], Height);
				}
				auto Justke = high_resolution_clock::now();

				if (kBound[1] <= kBound[0])
				{
					continue;
				}

				vector<pair<unsigned, float>> candidatePair{ {kBound[0], rBound[0]} };
				float rmincopy = rminmin;
				if (fileid == 4 || fileid == 5)
				{
					rmincopy = rBound[0];
				}
				//rBound[1] = JustRNoLeverINdex(Datas, q, m, kBound[1], rmincopy, candidatePair);

				auto Justrb = high_resolution_clock::now();

				rBound[1] = JustRHaveLeverINdex(Datas, q, m, kBound[1], rmincopy, candidatePair);
				auto Justre = high_resolution_clock::now();

				if (rBound[1] <= rBound[0])
				{
					continue;
				}
#ifdef DEBUG
				cout << "BEGIN MULTI PARAMETERS" << endl;
#endif // DEBUG

#ifdef RPri
				Rfirst(rBound, kBound, q, m, Datas, Height, candidatePair);
#endif
#ifdef KPri
				Kfirst(rmincopy, kBound, Datas, q, m, candidatePair);
#endif
				auto mid = high_resolution_clock::now();

				cout << "size" << endl;
				unsigned CurrentbestPeneaty = 65555;
				pair<unsigned, float> CurrentbestPair;
				vector<pair<pair<unsigned, unsigned>, unsigned>> LowerToId;

				vector<shared_ptr<RoctPlus>> AllR;
				unsigned rid = 0;
				for (auto& a : candidatePair)
				{
#ifdef DEBUG
					cout << "k: " << a.first << " r: " << a.second << endl;
#endif

					if (a.first > k)
					{
						break;
					}
					shared_ptr<RoctPlus> R = make_shared<RoctPlus>();
					LowerToId.push_back({ Rotchalf(q, a.first, a.second, Datas, Height, *R), rid++ });
					AllR.push_back(R);

				}
				sort(LowerToId.begin(), LowerToId.end(), [](const pair<pair<unsigned, unsigned>, unsigned>& a, const pair<pair<unsigned, unsigned>, unsigned>& b) {return a.first.first < b.first.first; });
				for (auto& [Lower, Id] : LowerToId)
				{
					auto& a = candidatePair[Id];
					unsigned cur = Rotcall(q, a.first, a.second, Datas, Height, CurrentbestPeneaty, Lower.second, *AllR[Id]);
					if (CurrentbestPeneaty > cur)
					{
						CurrentbestPeneaty = cur;
						CurrentbestPair = a;
					}
				}

				if (CurrentbestPeneaty == 65555)
					break;
				auto end = high_resolution_clock::now();

				cout << "size2" << endl;
				outTime << q << "," << m << "," << k << "," << r << ",";
				outTime << duration_cast<milliseconds>(Justke - Justkb).count() << ",";
				outTime << duration_cast<milliseconds>(Justre - Justrb).count() << ",";
				outTime << duration_cast<milliseconds>(mid - start).count() << ",";
				outTime << duration_cast<milliseconds>(end - mid).count() << ",";
				outTime << duration_cast<milliseconds>(end - start).count() << ",";
				outTime << CurrentbestPeneaty << ",";
#ifdef KPri
				if (fileid != 4 || fileid != 5)
				{
					outTime << Rotcmain(q, kBound[0], rBound[0], Datas, Height) << ",";
				}
				else
				{
					outTime << 0 << ",";
				}
				if (fileid != 3 || fileid != 5)
				{
					outTime << Rotcmain(q, kBound[1], rBound[1], Datas, Height) << ",";
				}
				else
				{
					outTime << 0 << ",";
				}
				outTime << kBound[0] << "_" << rBound[0] << ",";
				outTime << kBound[1] << "_" << rBound[1] << ",";
#endif
				outTime << to_string(CurrentbestPair.first) + "_" + to_string(CurrentbestPair.second) << endl;

				countw++;

			}
			if (countw > 20)
			{
				break;
			}
		}
	}
}



void ReadQuery(string Filename, vector<Query>& Querys)
{
	ifstream infile;
	infile.open(Filename, ios::in);
	if (!infile.is_open())
	{
		std::cout << Filename << " open fail" << endl;
		exit(0);
	}
	string infileString;
	

	while (getline(infile, infileString))
	{
		Query qq;
		string aa;
		stringstream aline(infileString);
		unsigned cou = 0;
		while (getline(aline, aa, ','))
		{
			if (cou == 0)
			{
				char cut;
				stringstream aaa(aa);
				aaa >> cut;
				aaa >> cut;
				aaa >> qq.k;
				cou++;
			}
			else if (cou == 1)
			{
				char cut;
				stringstream aaa(aa);
				aaa >> cut;
				aaa >> cut;
				aaa >> qq.r;
				cou++;
			}
			else if (cou == 2)
			{
				char cut;
				stringstream aaa(aa);
				aaa >> cut;
				aaa >> cut;
				aaa >> qq.q;
				cou++;
			}
			else
			{
				string cut;
				stringstream aaa(aa);
				aaa >> cut;
				aaa >> cut;
				unsigned ww;
				while (aaa >> ww)
				{
					qq.w.push_back(ww);
				}
				cou++;
			}
		}
		getline(infile, infileString);
		Querys.push_back(qq);
	}

}