#pragma once
#include "RotcPlus.h"


void DistanceSetsInsert(vector<vector<float>>& DistanceSets, int nq, int kmin, int kmax,
	vector<vector<unsigned>>& SubGraph, vector<pair<float, float>>& NewGraphG_Location, vector<int>& L_Degree);


unsigned JustK_NoLeverIndex(ReadData& Datas, unsigned q, unsigned m, unsigned k, float r, unsigned Height)
{
	OverloadedSearch overloadedSearch;

	auto start = high_resolution_clock::now();
	K_PreProcess k_preprocess;
	k_preprocess.Preprocess(q, m, k, r, Datas.GetGraphG_Location(), Datas.GetRtree_G(), Datas.GetarrayGraphG(), overloadedSearch);
	auto mid = high_resolution_clock::now();

#ifdef  DEBUG

	cout<< "The number of nodes in the graph is " << k_preprocess.GetGraphG_AfterPreProcess1().size() << endl;
#endif //  DEBUG

	pair<unsigned, unsigned> knqm = k_preprocess.Getnm();
	K_PrePruning k_prepruning;
	unsigned kprime = k;

	kprime = k_prepruning.Prepruning(kprime, knqm.first, knqm.second, r, Height, k_preprocess.GetGraphG_AfterPreProcess1(),
		k_preprocess.GetGraphG_Location_AfterPreProcess1(), k_preprocess.GetAPTree(), overloadedSearch);
	auto end = high_resolution_clock::now();

	if (k_prepruning.GetAllAfterPruning().empty())
	{
		cout << "because empty the best refined kprime is " << kprime << endl;
	}
	else if (kprime == k_prepruning.GetAllAfterPruning()[0].km)
	{
		cout << "because pre end, the best refined kprime is " << kprime << endl;
	}
	K_AccurateK k_accuratek;
	k_accuratek.TheAccurateK(kprime, knqm.first, knqm.second, r, k_prepruning.GetAllAfterPruning(),
		k_preprocess.GetGraphG_Location_AfterPreProcess1(), k_preprocess.GetAPTree(), overloadedSearch, k_preprocess.GetGraphG_AfterPreProcess1());
	auto endd = high_resolution_clock::now();

#ifdef  DEBUG
	std::cout << "Preprocess taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(mid - start).count() / 1e+6 << "ms" << endl;
	std::cout << "Prepruning taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(end - mid).count() / 1e+6 << "ms" << endl;
	std::cout << "actuallyk taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(endd - end).count() / 1e+6 << "ms" << endl;
	std::cout << "All JustKNoLeverIndex Refined time taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(endd - start).count() / 1e+6 << "ms" << endl;
	cout << "The best redined kprime is " << kprime << endl;
#endif
	return kprime;
}


unsigned JustK_HaveLeverIndex45(ReadData& Datas, unsigned q, unsigned m, unsigned k, float r, unsigned Height)
{
	OverloadedSearch overloadedSearch;
	vector<vector<unsigned>> NewGraph;
	unsigned kprime = k;
	float dis = distance(Datas.GetGraphG_Location()[q], Datas.GetGraphG_Location()[m]) / 2 + 0.001;
	pair<float, float> center = { (Datas.GetGraphG_Location()[q].first + Datas.GetGraphG_Location()[m].first) / 2.0, (Datas.GetGraphG_Location()[q].second + Datas.GetGraphG_Location()[m].second) / 2.0 };
	vector<int> L_Degree;
	vector<int> bin;
	vector<int> pos;
	vector<int> vert;
	Upk(kprime, q, m, 0, dis, center, Datas.GetRtree_G(),
		NewGraph, Datas.GetL_Degree(), overloadedSearch, Datas.GetarrayGraphG(), L_Degree, bin, pos, vert);
	return kprime;
}

unsigned JustK_HaveLeverIndex(ReadData& Datas, unsigned q, unsigned m, unsigned k, float r, unsigned Height)
{
	OverloadedSearch overloadedSearch;

	auto start = high_resolution_clock::now();
	K_PreProcess k_preprocess;
	k_preprocess.Preprocess(q, m, k, r, Datas.GetGraphG_Location(), Datas.GetRtree_G(), Datas.GetarrayGraphG(), overloadedSearch);
	vector<vector<int> > AfterProLeverCoreness;//coreness for any lever
	k_preprocess.GetAPTree().TreeCoreIndex(k_preprocess.GetGraphG_AfterPreProcess1().size(), AfterProLeverCoreness, k_preprocess.GetGraphG_AfterPreProcess1());
	auto mid = high_resolution_clock::now();

#ifdef  DEBUG
	cout << "The number of nodes in the graph is " << k_preprocess.GetGraphG_AfterPreProcess1().size() << endl;
#endif

	pair<unsigned, unsigned> knqm = k_preprocess.Getnm();
	K_PrePruning k_prepruning;
	unsigned kprime = k;

	kprime = k_prepruning.PrepruningIndex(kprime, knqm.first, knqm.second, r, Height, k_preprocess.GetGraphG_AfterPreProcess1(),
		k_preprocess.GetGraphG_Location_AfterPreProcess1(), k_preprocess.GetAPTree(), overloadedSearch, AfterProLeverCoreness);
	if (kprime == 0)
	{
		return 100000;
	}

	auto end = high_resolution_clock::now();

	if (k_prepruning.GetAllAfterPruning().empty())
	{
#ifdef  DEBUG

		cout << "because empty the best refined kprime is " << kprime << endl;
#endif
	}
	else if (kprime == k_prepruning.GetAllAfterPruning()[0].km)
	{
#ifdef  DEBUG

		cout << "because pre end, the best refined kprime is " << kprime << endl;
#endif
	}
	K_AccurateK k_accuratek;
	k_accuratek.TheAccurateKIndex(kprime, knqm.first, knqm.second, r, k_prepruning.GetAllAfterPruning(),
		k_preprocess.GetGraphG_Location_AfterPreProcess1(), k_preprocess.GetAPTree(), overloadedSearch, AfterProLeverCoreness, k_preprocess.GetGraphG_AfterPreProcess1());
	auto endd = high_resolution_clock::now();

#ifdef  DEBUG
	std::cout << "Preprocess taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(mid - start).count() / 1e+6 << "ms" << endl;
	std::cout << "Prepruning taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(end - mid).count() / 1e+6 << "ms" << endl;
	std::cout << "actuallyk taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(endd - end).count() / 1e+6 << "ms" << endl;
	std::cout << "All JustKHaveLeverIndex Refined time taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(endd - start).count() / 1e+6 << "ms" << endl;
	cout << "The best redined kprime is " << kprime << endl;
	cout << "Index useful Count is " << IndexUsednumber << endl;
#endif
	return kprime;
}



float JustRNoLeverINdex(ReadData& Datas, unsigned q, unsigned m, unsigned k, float& r, vector<pair<unsigned, float>>& candidatePair) 
{

	auto start = high_resolution_clock::now();
	OverloadedSearch overloadedSearch;
	R_Refr r_refr;
	float rend;
	if (r_refr.varify_Dqm(q, m, k, Datas.GetRtree_G(), Datas.GetGraphG_Location(), Datas.GetarrayGraphG(), rend, overloadedSearch))
	{
		cout << "Final refined r is d(q, m)/2: " << rend << endl;
		return rend;
	}
	auto mid = high_resolution_clock::now();
	
	R_Expension r_expension;
	if (!r_expension.DistanceSetsCalculate(q, m, k, r, Datas.GetGraphG_Location(), Datas.GetarrayGraphG(), Datas.GetL_Degree()))
	{
		cout << "No solution" << endl;
		return 0;
	}
	auto distancess = high_resolution_clock::now();

	pair<int, int> rnqm = r_expension.ExpensionCircle(q, m, k, r, Datas.GetRtree_G(), Datas.GetGraphG_Location(),
		Datas.GetarrayGraphG(), Datas.GetL_Degree(), overloadedSearch);
	if (rnqm.first == 0 && rnqm.second == 0)
	{
		cout << "Because pair No solution" << endl;
		return 0;
	}
	auto expension = high_resolution_clock::now();

	MyTree NewRtree;
	vector<pair<float, float>> NewGraphG_Location;
	priority_queue<DistanceAndVertex> NecessaryVertices;
	vector<DistanceAndVertex> AllVertices;
	r_expension.RebuildGraphandTree(rnqm.first, k, NewRtree, NewGraphG_Location, Datas.GetGraphG_Location(), NecessaryVertices, AllVertices);
	auto rebuild = high_resolution_clock::now();

	R_RefineRPlus r_refinerplus;
	float results = r_refinerplus.BestRefinationR(k, rnqm.first, rnqm.second, r_expension.GetSubGraph(),
		r_expension.GetL_Degree(), NewGraphG_Location, NewRtree, NecessaryVertices, AllVertices, overloadedSearch);
	auto endd = high_resolution_clock::now();

	
	candidatePair.push_back({ k, results });
#ifdef  DEBUG
	cout << "The Best Refined r is " << results << endl;
	std::cout << "varify_Dqm taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(mid - start).count() / 1e+6 << "ms" << endl;
	std::cout << "DistanceSetsCalculate taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(distancess - mid).count() / 1e+6 << "ms" << endl;
	std::cout << "expension taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(expension - distancess).count() / 1e+6 << "ms" << endl;
	std::cout << "rebuild taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(rebuild - expension).count() / 1e+6 << "ms" << endl;
	std::cout << "BestRefinationR taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(endd - rebuild).count() / 1e+6 << "ms" << endl;
	std::cout << "All JustRHaveLeverIndex Refined time taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(endd - start).count() / 1e+6 << "ms" << endl;
#endif
	return results;
}

float JustRHaveLeverINdex(ReadData& Datas, unsigned q, unsigned m, unsigned k, float r, vector<pair<unsigned, float>>& candidatePair)
{
	IndexUsednumber = 0;
	auto start = high_resolution_clock::now();
	OverloadedSearch overloadedSearch;
	R_Refr r_refr;
	float rend;
	if (r_refr.varify_Dqm(q, m, k, Datas.GetRtree_G(), Datas.GetGraphG_Location(), Datas.GetarrayGraphG(), rend, overloadedSearch))
	{
		cout << "Final refined r is d(q, m)/2: " << rend << endl;
		return rend;
	}
	auto mid = high_resolution_clock::now();

	R_Expension r_expension;
	if (!r_expension.DistanceSetsCalculate(q, m, k, r, Datas.GetGraphG_Location(), Datas.GetarrayGraphG(), Datas.GetL_Degree()))
	{
#ifdef DEBUG
		cout << "No solution" << endl; 
#endif
		return 0;
	}
	auto distancess = high_resolution_clock::now();

	pair<int, int> rnqm = r_expension.ExpensionCircle(q, m, k, r, Datas.GetRtree_G(), Datas.GetGraphG_Location(),
		Datas.GetarrayGraphG(), Datas.GetL_Degree(), overloadedSearch);
	cout << "Expen fini" << endl;
	if (rnqm.first == 0 && rnqm.second == 0)
	{
		cout << "Because pair No solution" << endl;
		return 0;
	}
	auto expension = high_resolution_clock::now();

	MyTree NewRtree;
	vector<pair<float, float>> NewGraphG_Location;
	priority_queue<DistanceAndVertex> NecessaryVertices;
	vector<DistanceAndVertex> AllVertices;
	r_expension.RebuildGraphandTree(rnqm.first, k, NewRtree, NewGraphG_Location, Datas.GetGraphG_Location(), NecessaryVertices, AllVertices);

#ifdef  DEBUG
	unsigned&& nesize = NecessaryVertices.size();
	unsigned&& allsize = AllVertices.size();
#endif

	vector<vector<int> > AfterProLeverCoreness;//coreness for any lever
	NewRtree.TreeCoreIndex(NewGraphG_Location.size(), AfterProLeverCoreness, r_expension.GetSubGraph());

	auto rebuild = high_resolution_clock::now();
	//cout << "Necessary size is " << nesize << " ||||| all size is  " << allsize << endl;

	R_RefineRPlus r_refinerplus;
	float results = r_refinerplus.BestRefinationRWithIndex(k, rnqm.first, rnqm.second, r_expension.GetSubGraph(),
		r_expension.GetL_Degree(), NewGraphG_Location, NewRtree, NecessaryVertices, AllVertices, overloadedSearch, AfterProLeverCoreness);
	auto endd = high_resolution_clock::now();
	candidatePair.push_back({ k, results });


#ifdef  DEBUG
	cout << "Necessary size is " << nesize << " ||||| all size is  " << allsize << endl;
	cout << "The Best Refined r is " << results << endl;
	cout << "RefinedR Index useful Count is " << IndexUsednumber << endl;

	std::cout << "varify_Dqm taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(mid - start).count() / 1e+6 << "ms" << endl;
	std::cout << "DistanceSetsCalculate taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(distancess - mid).count() / 1e+6 << "ms" << endl;
	std::cout << "expension taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(expension - distancess).count() / 1e+6 << "ms" << endl;
	std::cout << "rebuild taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(rebuild - expension).count() / 1e+6 << "ms" << endl;
	std::cout << "BestRefinationR taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(endd - rebuild).count() / 1e+6 << "ms" << endl;
	std::cout << "All JustRHaveLeverIndex Refined time taken : "
		<< std::chrono::duration_cast<std::chrono::nanoseconds>(endd - start).count() / 1e+6 << "ms" << endl;
#endif
	return results;
}

//���ڵ���k�ĺ�ѡpair���ɷ�ʽ
void Kfirst(float& rminmin, unsigned kBound[], ReadData& Datas, unsigned q, unsigned m, vector<pair<unsigned, float>>& candidatePair)
{
	//vector<thread> threads;
	for (unsigned k = kBound[0] + 1; k < kBound[1]; ++k)
	{
		//threads.emplace_back(JustR, ref(Datas), q, m, k, ref(rminmin), ref(candidatePair));
		//ÿ��k����1��JustR��ִ�г�ʼ�뾶����Ϊrminmin
		float r = JustRHaveLeverINdex(Datas, q, m, k, rminmin, candidatePair);
		//float r = JustRNoLeverINdex(Datas, q, m, k, rminmin, candidatePair);
		//float r = JustRNew(Datas, q, m, k, rminmin, candidatePair);
		//candidatePair.push_back({ k, r });
	}
	/*
	for(auto &t: threads)
	{
		t.join();
	}*/
}

//�����۰�r�ĺ�ѡpair���ɷ�ʽ
void Rfirst(float rBound[], unsigned kBound[], unsigned q, unsigned m, ReadData& Datas, unsigned Height, vector<pair<unsigned, float>>& candidatePair)
{
	OverloadedSearch overloadedSearch;
	//���ھ����Ͻ�Rbound[1]������O(q,Rbound[1]*2)��Χ�ڵģ�����q��m����ͨ��Kbound[0]-core
	R_Expension r_expension;
	vector<pair<float, float>> NewGraphG_Location;
	//ʹ�õ�tree�ķ�ʽ  ��2*rBound[q]Ϊ�뾶��qΪԲ�ģ�����һ������q��m����ͨ��k-core�����������k-core�ع�ͼ����
	MyTree NewRtree;
	pair<int, int> rnqm = r_expension.CreateANewGraphByGivenCircle(q, m, kBound[0], kBound[1], rBound[1], Datas.GetRtree_G(), Datas.GetGraphG_Location(),
		Datas.GetarrayGraphG(), Datas.GetL_Degree(), NewRtree, NewGraphG_Location, overloadedSearch);

	//ͼ�ؽ��Ժ󣬼���ͼ�����е�coreֵ����kmin�ĵ���q�ľ��룬��������Ľṹ�С�
	//���У��±�0����coreֵΪkmin�ĵ㣬�±�1����coreֵΪkmin+1�ĵ㣬�Դ����ơ�
	//Ƕ�׵������е�float������q�ľ��룬��Ҫ��������
	vector<vector<float>> DistanceSets;
	DistanceSetsInsert(DistanceSets, rnqm.first, kBound[0], kBound[1],
		r_expension.GetSubGraph(), NewGraphG_Location, r_expension.GetL_Degree());

	vector<pair<unsigned, pair<float, float>>> CandidatedGroup;
	for (unsigned k = kBound[0] + 1; k != kBound[1]; ++k)
	{
		CandidatedGroup.push_back({ k,{rBound[0],rBound[1]} });
	}
	unsigned i = 0;
	for (auto& distancesets : DistanceSets)
	{
		auto left = upper_bound(distancesets.begin(), distancesets.end(), CandidatedGroup[i].second.first) - 1;
		auto right = upper_bound(distancesets.begin(), distancesets.end(), CandidatedGroup[i].second.second);
		if(right == distancesets.end())
		{
			right--;
		}
		signed length = (right - left) / 2;
		float rnew = *(left + length);

		float leftr = *left;
		float rightr = *right;
		while (length > 1)
		{
			length = (right - left) / 2;
			rnew = *(left + length);
			//unsigned kprimes = JustvarifyK(Datas, q, m, kBound[0] + 1 + i, rnew, Height);
			unsigned kprimes = min(JustK_HaveLeverIndex(Datas, q, m, kBound[0] + i, rnew, Height), kBound[1] - 1);
			unsigned k = kBound[0] + 1 + i;
			if (kprimes < k)
			{
				left = left + length;
				leftr = *left;
				CandidatedGroup[i].second.first = rnew;
				for (unsigned ks = k + 1; ks != kBound[1]; ++ks)
				{
					CandidatedGroup[ks - k].second.first = max(rnew, CandidatedGroup[ks - k].second.first);
				}
				continue;
			}
			else if (kprimes == k)//����kprime+1��kBound[1]-1����߽磬�Լ���ǰkprimes���ұ߽�
			{
				right = left + length;
				rightr = *right;
				CandidatedGroup[i].second.second = min(rnew, CandidatedGroup[i].second.second);
				for (unsigned ks = kprimes + 1; ks != kBound[1]; ++ks)
				{
					CandidatedGroup[ks - k].second.first = max(rnew, CandidatedGroup[ks - k].second.first);
				}
			}
			else if (kprimes > k)//����k��kprimes���ұ߽��kprimes+1��kBound[1]-1����߽�
			{
				right = left + length;
				rightr = *right;
				for (unsigned ks = k; ks <= kprimes; ++ks)
				{
					CandidatedGroup[ks - k].second.second = min(rnew, CandidatedGroup[ks - k].second.second);
				}
				for (unsigned ks = kprimes + 1; ks != kBound[1]; ++ks)
				{
					CandidatedGroup[ks - k].second.first = max(rnew, CandidatedGroup[ks - k].second.first);
				}
			}
		}
		leftr = max(leftr, float(CandidatedGroup[i].second.first));
		rightr = min(rightr, float(CandidatedGroup[i].second.second));
		while (1)
		{	
			if (rightr - leftr < 0.01)
			{
				break;
			}
			rnew = (rightr + leftr) / 2.0;
			//unsigned kprimes = JustvarifyK(Datas, q, m, kBound[0] + 1 + i, rnew, Height);
			unsigned kprimes = min(JustK_HaveLeverIndex(Datas, q, m, kBound[0] + i, rnew, Height), kBound[1] - 1);
			unsigned k = kBound[0] + 1 + i;
			if (kprimes < k)
			{
				leftr = rnew;
				CandidatedGroup[i].second.first = rnew;
				continue;
			}
			else if (kprimes == k)//����kprime+1��kBound[1]-1����߽磬�Լ���ǰkprimes���ұ߽�
			{
				rightr = rnew;
				CandidatedGroup[i].second.second = min(rnew, CandidatedGroup[i].second.second);
				for (unsigned ks = kprimes + 1; ks != kBound[1]; ++ks)
				{
					CandidatedGroup[ks - k].second.first = max(rnew, CandidatedGroup[ks - k].second.first);
				}
			
			}
			else if (kprimes > k)//����k��kprimes���ұ߽��kprimes��kBound[1]-1����߽�
			{
				rightr = rnew;
				for (unsigned ks = k; ks <= kprimes; ++ks)
				{
					CandidatedGroup[ks - k].second.second = min(rnew, CandidatedGroup[ks - k].second.second);
				}
				for (unsigned ks = kprimes + 1; ks != kBound[1]; ++ks)
				{
					CandidatedGroup[ks - k].second.first = max(rnew, CandidatedGroup[ks - k].second.first);
				}
			}
		}
		//cout << "rnewis " << rnew << endl;
		++i;
	}
	for (auto& a : CandidatedGroup)
	{
		candidatePair.push_back({ a.first, a.second.second });
		//cout << a.first << ": <" << a.second.first << " |||| Use this: " << a.second.second << ">" << endl;
	}
}


bool compunique(float a, float b)
{
	//a��b�Ĳ�����10m��
	return (int(a * 1000) - int(b * 1000) == 0) || int(a * 1000) - int(b * 1000) == 1;

}
void DistanceSetsInsert(vector<vector<float>>& DistanceSets, int nq, int kmin, int kmax,
	vector<vector<unsigned>>& SubGraph, vector<pair<float, float>>& NewGraphG_Location, vector<int>& L_Degree)
{
	DistanceSets.resize(kmax - kmin - 1);
	for (unsigned i = 0; i != SubGraph.size(); ++i)
	{
		float distanceqi = distance(NewGraphG_Location[nq], NewGraphG_Location[i]) / 2.0;
		for (unsigned count = 0; count < kmax - kmin - 1; count++)
		{
			if (L_Degree[i] >= count + kmin + 1)
			{
				DistanceSets[count].push_back(distanceqi);
			}
		}
	}
	//�����ȥ��
	for (unsigned i = 0; i != DistanceSets.size(); ++i)
	{
		sort(DistanceSets[i].begin(), DistanceSets[i].end());
		auto ref = unique(DistanceSets[i].begin(), DistanceSets[i].end(), compunique);
		DistanceSets[i].erase(ref, DistanceSets[i].end());//
	}
}


unsigned Rotcmain(unsigned q, unsigned k, float r, ReadData & Datas, unsigned Height)
{
	RoctPlus rotcplus;
	rotcplus.NonFarAwayVertices(q, k, r, Datas.GetGraphG_Location(), Datas.GetRtree_G(), Datas.GetarrayGraphG(), Datas.GetL_Degree());
	unsigned&& ResultVerticesNumber = rotcplus.PreProcess(Height, k, r);
	return rotcplus.RotcPlusMain(r, k);
}

unsigned Rotcmain(unsigned q, unsigned k, float r, ReadData& Datas, unsigned Height, unsigned CurrentbestPeneaty)
{
	RoctPlus rotcplus;
	rotcplus.NonFarAwayVertices(q, k, r, Datas.GetGraphG_Location(), Datas.GetRtree_G(), Datas.GetarrayGraphG(), Datas.GetL_Degree());
	unsigned&& ResultVerticesNumber = rotcplus.PreProcess(Height, k, r);
	if (CurrentbestPeneaty < ResultVerticesNumber)
		return CurrentbestPeneaty;
	return min(rotcplus.RotcPlusPenaty(r, k, CurrentbestPeneaty), CurrentbestPeneaty);
}

pair<unsigned, unsigned> Rotchalf(unsigned q, unsigned k, float r, ReadData& Datas, unsigned Height, RoctPlus& rotcplus)
{
	rotcplus.NonFarAwayVertices(q, k, r, Datas.GetGraphG_Location(), Datas.GetRtree_G(), Datas.GetarrayGraphG(), Datas.GetL_Degree());
	unsigned ResultVerticesNumber = rotcplus.PreProcess(Height, k, r);
	return { rotcplus.GetGraphG_AfterPreProcessRotc().size() - rotcplus.GetCutVerticesCount(), ResultVerticesNumber };
}
unsigned Rotcall(unsigned q, unsigned k, float r, ReadData& Datas, unsigned Height, unsigned CurrentbestPeneaty, unsigned ResultVerticesNumber, RoctPlus& rotcplus)
{
	if (CurrentbestPeneaty < ResultVerticesNumber)
		return CurrentbestPeneaty;
	return min(rotcplus.RotcPlusPenaty(r, k, CurrentbestPeneaty), CurrentbestPeneaty);
}