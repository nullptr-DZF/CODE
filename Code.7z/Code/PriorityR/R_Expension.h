#pragma once
#include "R_Refr.h"
#include <queue>


void NewCircleCenterCalculate(float& r, pair<float, float>& CircleCenterUsed, const pair<float, float>& VLocation);


struct DistanceAndVertex
{
	DistanceAndVertex(float a, int b, pair<float, float> ll = { 0,0 })
	{
		distance = a;
		id = b;
		locations = ll;
	}
	float distance;
	int id;
	pair<float, float> locations;
	friend bool operator < (DistanceAndVertex a, DistanceAndVertex b)
	{
		return a.distance > b.distance;    //����С�ں�ʹ��С���ȳ�����
	}
};
class R_Expension
{
public:
	bool DistanceSetsCalculate(const int& q, const int& m, const int& k, float r, const vector<pair<float, float>>& GraphG_Location,
		const vector<vector<unsigned>>& GraphG, vector<int>& L_Degree);//����corenumber���������еľ��뼯��DistanceSet
	
	pair<int, int> ExpensionCircle(int q, int m, int k, float r, MyTree& Rtree_G, const vector<pair<float, float>>& GraphG_Location,
		const vector<vector<unsigned>>& GraphG, vector<int>& ExL_Degree, OverloadedSearch& overloadedSearch);
	void RebuildGraphandTree(int nq, int k, MyTree& NewRtree, vector<pair<float, float>>& NewGraphG_Location, const vector<pair<float, float>>& GraphG_Location,
		priority_queue<DistanceAndVertex>& NecessaryVertices, vector<DistanceAndVertex>& AllVertices);//VertexTree
	//Create A New Connected k-core contain q and m By Given Circle
	pair<int, int> CreateANewGraphByGivenCircle(int q, int m, int k, int kmax, float r, MyTree& Rtree_G, const vector<pair<float, float>>& GraphG_Location,
		vector<vector<unsigned>>& GraphG, vector<int>& ExL_Degree, MyTree& NewRtree, vector<pair<float, float>>& NewGraphG_Location, OverloadedSearch& overloadedSearch);

	inline vector<vector<unsigned>>& GetSubGraph()
	{
		return SubGraph;
	}
	inline pair<int, int>& Getbeingtoend()
	{
		return begintoend;
	}
	inline vector<int>& GetL_Degree()
	{
		return L_Degree;
	}

private:
	vector<vector<unsigned>> SubGraph;
	priority_queue<DistanceAndVertex> DistanceSet;

	//vector<int> Gk_NewOld;
	vector<int> L_Degree;
	vector<int> bin;
	vector<int> pos;
	vector<int> vert;

	pair<int, int> begintoend;
};

bool R_Expension::DistanceSetsCalculate(const int& q, const int& m, const int& k, float r, const vector<pair<float, float>>& GraphG_Location,
	const vector<vector<unsigned>>& GraphG, vector<int>& L_Degree)
{
	/**/
	for (auto& Gnei : GraphG[m])
	{
		if (L_Degree[Gnei] >= k)//
		{
			float distance = sqrtl(powl((GraphG_Location[Gnei].first - GraphG_Location[q].first), 2.0) + powl((GraphG_Location[Gnei].second - GraphG_Location[q].second), 2.0));
			DistanceAndVertex a(distance, Gnei);
			DistanceSet.push(a);
		}
	}




	float distance = sqrtl(powl((GraphG_Location[m].first - GraphG_Location[q].first), 2.0) + powl((GraphG_Location[m].second - GraphG_Location[q].second), 2.0));
	DistanceAndVertex a(distance, m);
	DistanceSet.push(a);
	/*
	if (DistanceSet.size() < k)
	{
		return false;
	}*/
	for (int i = 0; i != k - 2; ++i)// 
	{
		DistanceSet.pop();
	}
	float rnew = DistanceSet.top().distance;
	while (rnew < distance)// && DistanceSet.size() != 2   * 2
	{
		DistanceSet.pop();
		rnew = DistanceSet.top().distance;
	}
	/*
	for (auto& Gnei : GraphG[m])
	{
		float distancen = sqrtl(powl((GraphG_Location[Gnei].first - GraphG_Location[q].first), 2.0) + powl((GraphG_Location[Gnei].second - GraphG_Location[q].second), 2.0));
		if (L_Degree[Gnei] >= k && distancen >= rnew)// - 2
		{
			for (auto& Gneinei : GraphG[Gnei])
			{
				if (L_Degree[Gneinei] >= k)//- 2
				{
					float distance = sqrtl(powl((GraphG_Location[Gneinei].first - GraphG_Location[q].first), 2.0) + powl((GraphG_Location[Gneinei].second - GraphG_Location[q].second), 2.0));
					if(distance > rnew)
					{
						DistanceAndVertex a(distance, Gneinei);
						DistanceSet.push(a);
					}
				}
			}
		}
	}*/

	return true;
	/*
	if (DistanceSet.size() != 1 && DistanceSet.top().distance < 2 * r)
	{
		DistanceSet.push()
	}*/
	//cout << " DistanceSet Size is" << DistanceSet.size() << endl;
}

pair<int, int> R_Expension::ExpensionCircle(int q, int m, int k, float r, MyTree& Rtree_G, const vector<pair<float, float>>& GraphG_Location,
	const vector<vector<unsigned>>& GraphG, vector<int>& ExL_Degree, OverloadedSearch& overloadedSearch)
{
	//initial the circle, circle center is q, circle radius is DistanceSet.top().distance
	float CircleRadius = DistanceSet.top().distance;
	DistanceSet.pop();
	pair<float, float> CircleCenter = { GraphG_Location[q].first, GraphG_Location[q].second };
	overloadedSearch.SearchR_ExpensionUp(GraphG_Location.size() / 5, k, CircleCenter, CircleRadius, Rtree_G, SubGraph, CandidateGk, Gk_OldNew, GraphG, ExL_Degree);
	auto nq = Gk_OldNew[q];
	auto nm = Gk_OldNew[m];

	float CircleRadiusNew = CircleRadius;
	pair<float, float> CircleCenterNew = CircleCenter;

	float olddis = 2 * r, newdis = 0;
	while (!DistanceSet.empty())
	{
		newdis = DistanceSet.top().distance;
		int CurrentID = DistanceSet.top().id;
		DistanceSet.pop();

		NewCircleCenterCalculate(CircleRadiusNew, CircleCenterNew, GraphG_Location[CurrentID]);
		//reflash graph by extension vertices
		overloadedSearch.SearchRExpension(CircleCenter, CircleRadius, CircleCenterNew, CircleRadiusNew, Rtree_G, SubGraph, CandidateGk,
			Gk_OldNew, GraphG, ExL_Degree, begintoend);
		/*
		unsigned countss = 0;
		for (auto& nei : SubGraph)
		{
			countss += nei.size();
		}
		cout << countss << " count is " << endl;*/
		if (Rvarify_kcore(nq, nm, k, SubGraph, L_Degree, bin, pos, vert))
		{
			if (Rconnected_verifySingleThread(nq, nm, k, SubGraph, L_Degree))
			{
				//�������Ȧ��CandidateGk��beingtoend,�Լ�����id�����ͼsubgraph���Լ���Ӧ�ڵ��L_Degree��k�����µ�)���Լ��ɵ�id���µ�id�Ķ�ӦGk_OldNew���Լ��෴��Gk_NewOld
				return make_pair(nq, nm);
			}
		}

		CircleRadius = CircleRadiusNew;
		CircleCenter = CircleCenterNew;
		olddis = newdis;
	}
	for (auto& a : CandidateGk)
	{
		Find[a] = true;
	}
	//�����ھӼ�����Ȼ���������������ٴ���������0,0
	return make_pair(0, 0);
}

void NewCircleCenterCalculate(float& rr, pair<float, float>& CircleCenterUsed, const pair<float, float>& VLocation)
{
	float && distanceCV = sqrtl(powl((VLocation.first - CircleCenterUsed.first), 2.0) + powl((VLocation.second - CircleCenterUsed.second), 2.0));
	float && x1 = fabs((VLocation.first - CircleCenterUsed.first)) / distanceCV * (distanceCV + rr);
	float && y1 = fabs((VLocation.second - CircleCenterUsed.second)) / distanceCV * (distanceCV + rr);
	float wx, wy;
	if (VLocation.first > CircleCenterUsed.first)
	{
		wx = VLocation.first - x1;
	}
	else
	{
		wx = VLocation.first + x1;
	}
	if (VLocation.second > CircleCenterUsed.second)
	{
		wy = VLocation.second - y1;
	}
	else
	{
		wy = VLocation.second + y1;
	}
	//cout << distanceCV << " " << 2 * r << endl;
	rr = (distanceCV + rr) / 2.0;
	CircleCenterUsed = { (VLocation.first + wx) / 2, (VLocation.second + wy) / 2 };
}

/**/
bool comp(DistanceAndVertex a, DistanceAndVertex b)
{
	return a.distance < b.distance;    //����С�ں�ʹ��С���ȳ�����
}

inline void R_Expension::RebuildGraphandTree(int nq, int k, MyTree& NewRtree, vector<pair<float, float>>& NewGraphG_Location, const vector<pair<float, float>>& GraphG_Location,
	priority_queue<DistanceAndVertex>& NecessaryVertices, vector<DistanceAndVertex>& AllVertices)
{
	for (auto& a : CandidateGk)
	{
		Find[a] = true;
	}
	for (int i = begintoend.first; i != begintoend.second; ++i)
	{
		float && distance = sqrtl(powl((GraphG_Location[CandidateGk[i]].first - GraphG_Location[CandidateGk[nq]].first), 2.0) 
			+ powl((GraphG_Location[CandidateGk[i]].second - GraphG_Location[CandidateGk[nq]].second), 2.0));
		DistanceAndVertex a(distance, i);
		NecessaryVertices.push(a);
	}
	AllVertices.reserve(SubGraph.size());
	NewGraphG_Location.reserve(SubGraph.size());
	for (int i = 0; i != SubGraph.size(); ++i)
	{
		float && distance = sqrtl(powl((GraphG_Location[CandidateGk[i]].first - GraphG_Location[CandidateGk[nq]].first), 2.0)
			+ powl((GraphG_Location[CandidateGk[i]].second - GraphG_Location[CandidateGk[nq]].second), 2.0));
		DistanceAndVertex a(distance, i, GraphG_Location[CandidateGk[i]]);
		AllVertices.push_back(a);
		float lati = GraphG_Location[CandidateGk[i]].first;
		float longi = GraphG_Location[CandidateGk[i]].second;
		float amin[] = { lati, longi };
		float amax[] = { lati, longi };
		//Vertex v(id, lati, longi);
		if (L_Degree[i] >= k)
		{
			NewRtree.Insert(amin, amax, { i, {lati, longi} });
		}
		NewGraphG_Location.push_back({ lati, longi });
	}
	sort(AllVertices.begin(), AllVertices.end(), comp);
	AllVertices.erase(unique(std::execution::par, AllVertices.begin(), AllVertices.end(), [](const DistanceAndVertex& a, const DistanceAndVertex& b) {return b.locations == a.locations; }), AllVertices.end());
}


void FindAConnectedKcore(vector<unsigned> &NewCandidateGk, int k, int q, unsigned count, const vector<vector<unsigned>>& subgraph, vector<int>& L_Degree)
{
	NewCandidateGk.reserve(subgraph.size());
	vector<bool> FindOrNot(subgraph.size(), false);
	vector<unsigned> WaitToFind;
	WaitToFind.reserve(subgraph.size());
	WaitToFind.push_back(q);
	FindOrNot[q] = true;
	while (!WaitToFind.empty())
	{
		unsigned&& temp = std::move(WaitToFind.back());
		WaitToFind.pop_back();
		NewCandidateGk.push_back(temp);
		Find[temp] = false;
		Gk_OldNew[temp] = count++;
		for (auto& nei : subgraph[temp])
		{
			if (FindOrNot[nei] == false)
			{
				FindOrNot[nei] = true;
				if (L_Degree[nei] >= k)
				{
					WaitToFind.push_back(nei);
				}
			}
		}
	}
}

pair<int, int> R_Expension::CreateANewGraphByGivenCircle(int q, int m, int kmin, int kmax, float r, MyTree& Rtree_G, const vector<pair<float, float>>& GraphG_Location,
	vector<vector<unsigned>>& GraphG, vector<int>& ExL_Degree, MyTree& NewRtree, vector<pair<float, float>>& NewGraphG_Location, OverloadedSearch& overloadedSearch)
{
	float&& CircleRadius = 2 * r;
	pair<float, float> CircleCenter = { GraphG_Location[q].first, GraphG_Location[q].second };
	overloadedSearch.SearchEdgeByDegree(ExL_Degree, kmin, CircleCenter, CircleRadius, Rtree_G, SubGraph, CandidateGk, GraphG);
	unsigned nq = Gk_OldNew[q]; unsigned nm = Gk_OldNew[m];
	Rvarify_kcore(nq, nm, kmax, SubGraph, L_Degree, bin, pos, vert);//input k is kBound[1]
	//cout << L_Degree[nq] << " " << L_Degree[nm] << endl;

	vector<unsigned> NewCandiGk;
	FindAConnectedKcore(NewCandiGk, kmin, nq, 0, SubGraph, L_Degree);
	vector<vector<unsigned>> NewSubGraph;
	Great_Graph_ByPoint(NewCandiGk, NewSubGraph, SubGraph);

	nq = Gk_OldNew[nq]; nm = Gk_OldNew[nm];

	for (auto& a : NewCandiGk)
	{
		Find[a] = true;
	}
	NewGraphG_Location.reserve(NewSubGraph.size());
	for(unsigned i = 0; i!= NewCandiGk.size(); ++i)
	{
		pair<float, float> loca = GraphG_Location[CandidateGk[NewCandiGk[i]]];
		float amin[] = { loca.first, loca.second };
		float amax[] = { loca.first, loca.second };
		//Vertex v(id, lati, longi);
		NewRtree.Insert(amin, amax, { i, loca });
		NewGraphG_Location.push_back(loca);
	}
	swap(SubGraph, NewSubGraph);
	Rvarify_kcore(nq, nm, kmax, SubGraph, L_Degree, bin, pos, vert);//input k is kBound[1]

	return make_pair(nq, nm);
}