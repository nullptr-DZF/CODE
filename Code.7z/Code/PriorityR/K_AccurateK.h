#pragma once
#include "K_PrePruning.h"

typedef pair<float, float> Point;

bool CantainQandM(const Point& center, int nq, int nm, vector<pair<float, float>>& GraphG_Location_AfterPreProcess, float r,
    pair<LocationType, LocationType>& boundingbox);
void calculateCircleCenter(const Point& x, const Point& y, float r, float distance, vector<Point>& CircleCenters,
    pair<LocationType, LocationType>& boundingbox, int nq, int nm, vector<pair<float, float>>& GraphG_Location_AfterPreProcess);

bool Polepruning(unsigned& kprim, unsigned nq, unsigned nm, float r, pair<float, float>& center, MyTree& RTree_GAfterPreProcess,
    vector<vector<unsigned>>& NewGraph, vector<int>& Exdegree, OverloadedSearch& overloadedSearch, vector<vector<unsigned>>& GraphG_AfterPreProcess,
    vector<int>& L_Degree, vector<int>& bin, vector<int>& pos, vector<int>& vert);
bool PolepruningIndex(unsigned& kprim, unsigned nq, unsigned nm, float r, pair<float, float>& center, MyTree& RTree_GAfterPreProcess,
    vector<vector<unsigned>>& NewGraph, vector<int>& Exdegree, OverloadedSearch& overloadedSearch, vector<vector<unsigned>>& GraphG_AfterPreProcess,
    vector<int>& L_Degree, vector<int>& bin, vector<int>& pos, vector<int>& vert, vector<vector<int> >& AfterProLeverCoreness);
void Upk(unsigned& kprim, unsigned nq, unsigned nm, unsigned size, float r, pair<float, float>& center, MyTree& RTree_GAfterPreProcess,
    vector<vector<unsigned>>& NewGraph, vector<int>& Exdegree, OverloadedSearch& overloadedSearch, vector<vector<unsigned>>& GraphG_AfterPreProcess,
    vector<int>& L_Degree, vector<int>& bin, vector<int>& pos, vector<int>& vert);
void UpkIndex(unsigned& kprim, unsigned nq, unsigned nm, unsigned size, float r, pair<float, float>& center, MyTree& RTree_GAfterPreProcess,
    vector<vector<unsigned>>& NewGraph, vector<int>& Exdegree, OverloadedSearch& overloadedSearch, vector<vector<unsigned>>& GraphG_AfterPreProcess,
    vector<int>& L_Degree, vector<int>& bin, vector<int>& pos, vector<int>& vert, vector<vector<int> >& AfterProLeverCoreness);


class K_AccurateK
{
public:
    void TheAccurateK(unsigned& kprime, int nq, int nm, float r, vector<AfterPruning>& AllAfterPruning,
        vector<pair<float, float>>& GraphG_Location_AfterPreProcess, MyTree& REdgeTree_GAfterPreProcess, OverloadedSearch& overloadedSearch, 
        vector<vector<unsigned>>& GraphG_AfterPreProcess);
    void TheAccurateKIndex(unsigned& kprime, int nq, int nm, float r, vector<AfterPruning>& AllAfterPruning,
        vector<pair<float, float>>& GraphG_Location_AfterPreProcess, MyTree& RTree_GAfterPreProcess, OverloadedSearch& overloadedSearch, vector<vector<int> >& AfterProLeverCoreness
        , vector<vector<unsigned>>& GraphG_AfterPreProcess);

private:

};


void K_AccurateK::TheAccurateK(unsigned& kprime, int nq, int nm, float r, vector<AfterPruning>& AllAfterPruning,
    vector<pair<float, float>>& GraphG_Location_AfterPreProcess, MyTree& RTree_GAfterPreProcess, OverloadedSearch& overloadedSearch
    , vector<vector<unsigned>>& GraphG_AfterPreProcess)
{
    unsigned Exdegree = kprime;
    unsigned allnodesize = GraphG_Location_AfterPreProcess.size();
    vector<unsigned> CheckOrNot(allnodesize, 0);
    vector<Point> CircleCenters;
    CircleCenters.reserve(10);
    vector<vector<unsigned>> NewGraph;

    vector<int> L_Degree;
    vector<int> bin;
    vector<int> pos;
    vector<int> vert;
    //begin to the biggest km of AllAfterpruning
    for (auto& allafterpruning : AllAfterPruning)
    {
        if (kprime >= allafterpruning.km)
        {
            return;
        }
        unsigned nodesSize = allafterpruning.degree.size();
        for (unsigned node = 0; node != nodesSize; ++node)
        {
            if (allafterpruning.degree[node] <= kprime || CheckOrNot[node] == 1)//the pole be varified and be pruning
            {
                continue;
            }
            //in-process pruning 1
            if (CheckOrNot[node] == 0)//varify whether the pole can be pruning
            {
                if (Polepruning(kprime, nq, nm, r, GraphG_Location_AfterPreProcess[node], RTree_GAfterPreProcess, NewGraph,
                    allafterpruning.degree, overloadedSearch, GraphG_AfterPreProcess, L_Degree, bin, pos, vert))
                {
                    // can be pruning
                    CheckOrNot[node] = 1;
                    continue;
                }
                CheckOrNot[node] = 2;

            }
            //the pole be varified and not be pruning
            for (unsigned nodee = node + 1; nodee != nodesSize; ++nodee)
            {
                if (allafterpruning.degree[nodee] <= kprime || CheckOrNot[nodee] == 1)
                {
                    continue;
                }
                //create binary vertex bounded circle
                float&& distance = std::hypot(GraphG_Location_AfterPreProcess[node].first - GraphG_Location_AfterPreProcess[nodee].first,
                    GraphG_Location_AfterPreProcess[node].second - GraphG_Location_AfterPreProcess[nodee].second);
                calculateCircleCenter(GraphG_Location_AfterPreProcess[node], GraphG_Location_AfterPreProcess[nodee], r, distance,
                    CircleCenters, allafterpruning.boundingbox, nq, nm, GraphG_Location_AfterPreProcess);
                while (!CircleCenters.empty())
                {
                    Upk(kprime, nq, nm, allnodesize, r, CircleCenters.back(), RTree_GAfterPreProcess, 
                        NewGraph, allafterpruning.degree, overloadedSearch, GraphG_AfterPreProcess, L_Degree, bin, pos, vert);
                    CircleCenters.pop_back();
                }
                if (kprime >= allafterpruning.km)
                {
                    return;
                }
            }
        }
    }
}

void K_AccurateK::TheAccurateKIndex(unsigned& kprime, int nq, int nm, float r, vector<AfterPruning>& AllAfterPruning,
    vector<pair<float, float>>& GraphG_Location_AfterPreProcess, MyTree& RTree_GAfterPreProcess, OverloadedSearch& overloadedSearch, vector<vector<int> >& AfterProLeverCoreness
    , vector<vector<unsigned>>& GraphG_AfterPreProcess)
{
    unsigned Exdegree = kprime;
    unsigned allnodesize = GraphG_Location_AfterPreProcess.size();
    vector<unsigned> CheckOrNot(allnodesize, 0);
    vector<Point> CircleCenters;
    CircleCenters.reserve(10);
    vector<vector<unsigned>> NewGraph;

    vector<int> L_Degree;
    vector<int> bin;
    vector<int> pos;
    vector<int> vert;
    //begin to the biggest km of AllAfterpruning

    auto start = high_resolution_clock::now();

    for (auto& allafterpruning : AllAfterPruning)
    {
        auto end = std::chrono::high_resolution_clock::now();
        //end - start   ms
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
        //time out
        if (duration.count() > 100000)
        {
            cout << "time out JustK" << endl;
            return ;
        }


        if (kprime >= allafterpruning.km)
        {
            return;
        }
        unsigned nodesSize = allafterpruning.degree.size();
        for (unsigned node = 0; node != nodesSize; ++node)
        {
            if (allafterpruning.degree[node] <= kprime || CheckOrNot[node] == 1)//the pole be varified and be pruning
            {
                continue;
            }
            //in-process pruning 1
            if (CheckOrNot[node] == 0)//varify whether the pole can be pruning
            {
                if (PolepruningIndex(kprime, nq, nm, r, GraphG_Location_AfterPreProcess[node], RTree_GAfterPreProcess, NewGraph,
                    allafterpruning.degree, overloadedSearch, GraphG_AfterPreProcess, L_Degree, bin, pos, vert, AfterProLeverCoreness))
                {
                    // can be pruning
                    CheckOrNot[node] = 1;
                    continue;
                }
                CheckOrNot[node] = 2;

            }
            //the pole be varified and not be pruning
            for (unsigned nodee = node + 1; nodee != nodesSize; ++nodee)
            {
                if (allafterpruning.degree[nodee] <= kprime || CheckOrNot[nodee] == 1)
                {
                    continue;
                }
                //create binary vertex bounded circle
                float&& distance = std::hypot(GraphG_Location_AfterPreProcess[node].first - GraphG_Location_AfterPreProcess[nodee].first,
                    GraphG_Location_AfterPreProcess[node].second - GraphG_Location_AfterPreProcess[nodee].second);
                calculateCircleCenter(GraphG_Location_AfterPreProcess[node], GraphG_Location_AfterPreProcess[nodee], r, distance,
                    CircleCenters, allafterpruning.boundingbox, nq, nm, GraphG_Location_AfterPreProcess);
                while (!CircleCenters.empty())
                {
                    UpkIndex(kprime, nq, nm, allnodesize, r, CircleCenters.back(), RTree_GAfterPreProcess,
                        NewGraph, allafterpruning.degree, overloadedSearch, GraphG_AfterPreProcess, L_Degree, bin, pos, vert, AfterProLeverCoreness);
                    CircleCenters.pop_back();
                }
                if (kprime >= allafterpruning.km)
                {
                    return;
                }
            }
        }
    }
}

//varify whether the most better kprim
void Upk(unsigned& kprim, unsigned nq, unsigned nm, unsigned size, float r, pair<float, float>& center, MyTree& RTree_GAfterPreProcess,
    vector<vector<unsigned>>& NewGraph, vector<int>& Exdegree, OverloadedSearch& overloadedSearch, vector<vector<unsigned>>& GraphG_AfterPreProcess,
    vector<int>& L_Degree, vector<int>& bin, vector<int>& pos, vector<int>& vert)
{
    overloadedSearch.SearchEdgeByDegree(Exdegree, kprim, center, r, RTree_GAfterPreProcess, NewGraph, CandidateGk, GraphG_AfterPreProcess);
    nq = Gk_OldNew[nq]; nm = Gk_OldNew[nm];
    varify_kcore(nq, nm, NewGraph, L_Degree, bin, pos, vert);
    if (L_Degree[nq] <= kprim || L_Degree[nm] <= kprim)
    {
        return;//pruning
    }
    //unsigned km = ConnectedVarifyNoconnecttest(kprim, nq, nm, L_Degree, bin, NewGraph);
    unsigned km = ConnectedVarifyNoconnect(nq, nm, L_Degree, bin, NewGraph);
    if (km > kprim)
    {
        kprim = km;
        return;
    }
    return;
}

//varify whether the most better kprim
void UpkIndex(unsigned& kprim, unsigned nq, unsigned nm, unsigned size, float r, pair<float, float>& center, MyTree& RTree_GAfterPreProcess,
    vector<vector<unsigned>>& NewGraph, vector<int>& Exdegree, OverloadedSearch& overloadedSearch, vector<vector<unsigned>>& GraphG_AfterPreProcess,
    vector<int>& L_Degree, vector<int>& bin, vector<int>& pos, vector<int>& vert, vector<vector<int> >& AfterProLeverCoreness)
{
    if (overloadedSearch.SearchEdgeByDegreeIndex(nq, nm, Exdegree, kprim, center, r, RTree_GAfterPreProcess, NewGraph, CandidateGk, GraphG_AfterPreProcess, AfterProLeverCoreness) == 0)
    {
        //cout << "Index Useful UPK" << endl;
        return;////pruning
    }
    nq = Gk_OldNew[nq]; nm = Gk_OldNew[nm];
    varify_kcore(nq, nm, NewGraph, L_Degree, bin, pos, vert);
    if (L_Degree[nq] <= kprim || L_Degree[nm] <= kprim)
    {
        return;//pruning
    }
    //unsigned km = ConnectedVarifyNoconnecttest(kprim, nq, nm, L_Degree, bin, NewGraph);
    unsigned km = ConnectedVarifyNoconnect(nq, nm, L_Degree, bin, NewGraph);
    if (km > kprim)
    {
        kprim = km;
        return;
    }
    return;
}

//varify whether the pole can be pruning
bool Polepruning(unsigned& kprim, unsigned nq, unsigned nm, float r, pair<float, float>& center, MyTree& RTree_GAfterPreProcess,
    vector<vector<unsigned>>& NewGraph, vector<int>& Exdegree, OverloadedSearch& overloadedSearch, vector<vector<unsigned>>& GraphG_AfterPreProcess,
    vector<int>& L_Degree, vector<int>& bin, vector<int>& pos, vector<int>& vert)
{
    overloadedSearch.SearchEdgeByDegree(Exdegree, kprim, center, 2 * r, RTree_GAfterPreProcess, NewGraph, CandidateGk, GraphG_AfterPreProcess);
    nq = Gk_OldNew[nq]; nm = Gk_OldNew[nm];
    varify_kcore(nq, nm, NewGraph, L_Degree, bin, pos, vert);
    if (L_Degree[nq] <= kprim || L_Degree[nm] <= kprim)
    {
        return true;//pruning
    }
    unsigned km = ConnectedVarifyNoconnect(nq, nm, L_Degree, bin, NewGraph);
    if (km <= kprim)
    {
        return true;//pruning
    }
    return false;
}

bool PolepruningIndex(unsigned& kprim, unsigned nq, unsigned nm, float r, pair<float, float>& center, MyTree& RTree_GAfterPreProcess,
    vector<vector<unsigned>>& NewGraph, vector<int>& Exdegree, OverloadedSearch& overloadedSearch, vector<vector<unsigned>>& GraphG_AfterPreProcess,
    vector<int>& L_Degree, vector<int>& bin, vector<int>& pos, vector<int>& vert, vector<vector<int> >& AfterProLeverCoreness)
{
    if (overloadedSearch.SearchEdgeByDegreeIndex(nq, nm, Exdegree, kprim, center, 2 * r, RTree_GAfterPreProcess, NewGraph, CandidateGk, GraphG_AfterPreProcess, AfterProLeverCoreness) == 0)
    {
        //cout << "Index Useful Pole" << endl;
        return true;////pruning
    }
    nq = Gk_OldNew[nq]; nm = Gk_OldNew[nm];
    varify_kcore(nq, nm, NewGraph, L_Degree, bin, pos, vert);
    if (L_Degree[nq] <= kprim || L_Degree[nm] <= kprim)
    {
        return true;//pruning
    }
    unsigned km = ConnectedVarifyNoconnect(nq, nm, L_Degree, bin, NewGraph);
    if (km <= kprim)
    {
        return true;//pruning
    }
    return false;
}

//whether the circle(center,r) can cantain both q and m, and whether the center belong to bounding box
bool CantainQandM(const Point& center, int nq, int nm, vector<pair<float, float>>& GraphG_Location_AfterPreProcess, float r,
    pair<LocationType, LocationType>& boundingbox)
{
    if (center.first < boundingbox.first.first || center.first > boundingbox.second.first ||
        center.second < boundingbox.first.second || center.second > boundingbox.second.second)
    {
        return false;
    }
    float distanceq = std::hypot(GraphG_Location_AfterPreProcess[nq].first - center.first,
        GraphG_Location_AfterPreProcess[nq].second - center.second);
    float distancem = std::hypot(GraphG_Location_AfterPreProcess[nm].first - center.first,
        GraphG_Location_AfterPreProcess[nm].second - center.second);
    if (distanceq <= r + 0.0001 && distancem <= r + 0.0001)
    {
        return true;
    }
    return false;
}

void calculateCircleCenter(const Point& x, const Point& y, float r, float distance, vector<Point>& CircleCenters,
    pair<LocationType, LocationType>& boundingbox, int nq, int nm, vector<pair<float, float>>& GraphG_Location_AfterPreProcess)
{
    if (distance >= 2 * r - 0.001 && distance <= 2 * r + 0.000001)
    {
        // Only one circle center
        Point center;
        center.first = (x.first + y.first) / 2.0;
        center.second = (x.second + y.second) / 2.0;
        if (CantainQandM(center, nq, nm, GraphG_Location_AfterPreProcess, r, boundingbox))
        {
            CircleCenters.push_back(center);
        }
    }
    else if (distance < 2 * r - 0.001)
    {
        // Two circle centers
        float midpointX = (x.first + y.first) / 2.0;
        float midpointY = (x.second + y.second) / 2.0;

        float unitX = (y.first - x.first) / distance;
        double unitY = (y.second - x.second) / distance;

        double offset = std::sqrt(r * r - (distance / 2) * (distance / 2));

        Point center;
        center.first = midpointX + offset * unitY;
        center.second = midpointY - offset * unitX;
        if (CantainQandM(center, nq, nm, GraphG_Location_AfterPreProcess, r, boundingbox))
        {
            CircleCenters.push_back(center);
        }
        center.first = midpointX - offset * unitY;
        center.second = midpointY + offset * unitX;
        if (CantainQandM(center, nq, nm, GraphG_Location_AfterPreProcess, r, boundingbox))
        {
            CircleCenters.push_back(center);
        }
    }
}