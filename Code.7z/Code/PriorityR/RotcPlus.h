#pragma once
#define _USE_MATH_DEFINES
#include "K_AccurateK.h"
#include "R_RefineRPlus.h"

#define SQR2 0.70710678118654752440084436210485

void ConnectedGraphVarify(unsigned k, unsigned q, vector<int>& L_Degree, const vector<vector<unsigned>>& Gx, vector<bool>& Result, unsigned& VerticesCount);
void CutCircle(pair<pair<float, float>, float>& circle, vector<pair<pair<float, float>, float>>& Yc);
bool ROTCvarify_kcore(int q, int k, const vector<vector<unsigned>>& Gx, vector<int>& L_Degree, vector<int>& bin, vector<int>& pos
	, vector<int>& vert);


class RoctPlus
{
public:
	RoctPlus() 
	{

	};
	~RoctPlus()
	{

	};

	inline vector<vector<unsigned>>& GetGraphG_AfterPreProcessRotc() { return GraphG_AfterPreProcessRotc; }
	inline vector<pair<float, float>>& GetGraphG_Location_AfterPreProcessRotc() { return GraphG_Location_AfterPreProcessRotc; }
	inline MyTree& GetRTree_AfterPreProcessRotc() { return RTree_AfterPreProcessRotc; }
	inline unsigned& GetCutVerticesCount() { return CutVerticesCount; }


	void NonFarAwayVertices(unsigned q, unsigned k, float r, vector<pair<float, float>>& GraphG_Location,
		MyTree& Rtree_G, vector<std::vector<unsigned>>& arrayGraphG, vector<int>& Exdegrees);
	unsigned PreProcess(unsigned Height, unsigned k, float r);
	unsigned RotcPlusMain(float r, unsigned k);
	unsigned RotcPlusPenaty(float r, unsigned k, unsigned CurrentbestPenaty);
	bool PoleVarify(unsigned u, float r, unsigned k, vector<vector<unsigned>>& ExNewGraph, vector<unsigned>& Connect);




private:

	vector<vector<unsigned>> GraphG_AfterPreProcessRotc;
	vector<pair<float, float>> GraphG_Location_AfterPreProcessRotc;
	MyTree RTree_AfterPreProcessRotc;
	OverloadedSearch overloadedSearch;

	vector<int> L_Degree;
	vector<int> bin;
	vector<int> pos;
	vector<int> vert;

	vector<bool> Results;
	unsigned VerticesCount = 0;
	unsigned CutVerticesCount = 0;

	vector<bool> VGk;

	unsigned q;
};

void RoctPlus::NonFarAwayVertices(unsigned q, unsigned k, float r, vector<pair<float, float>>& GraphG_Location,
	MyTree& Rtree_G, vector<std::vector<unsigned>>& arrayGraphG, vector<int>& Exdegrees)
{
	overloadedSearch.SearchROTCfaraway(Exdegrees, k, GraphG_Location[q], 2 * r, Rtree_G, GraphG_AfterPreProcessRotc, CandidateGk,
		arrayGraphG);
	unsigned nq = Gk_OldNew[q];
	ROTCvarify_kcore(nq, k, GraphG_AfterPreProcessRotc, L_Degree, bin, pos, vert);//input k is kBound[1]
#ifdef DEBUG
	cout << "L_Degree[nq] : " << L_Degree[nq] << endl;
#endif // DEBUG
	vector<unsigned> NewCandiGk;
	FindAConnectedKcore(NewCandiGk, k, nq, 0, GraphG_AfterPreProcessRotc, L_Degree);
	vector<vector<unsigned>> NewSubGraph;
	Great_Graph_ByPoint(NewCandiGk, NewSubGraph, GraphG_AfterPreProcessRotc);
	this->q = nq = Gk_OldNew[nq];
	for (auto& a : NewCandiGk)
	{
		Find[a] = true;
	}
	GraphG_Location_AfterPreProcessRotc.reserve(NewSubGraph.size());
	for (unsigned i = 0; i != NewCandiGk.size(); ++i)
	{
		pair<float, float> loca = GraphG_Location[CandidateGk[NewCandiGk[i]]];
		float amin[] = { loca.first, loca.second };
		float amax[] = { loca.first, loca.second };
		//Vertex v(id, lati, longi);
		RTree_AfterPreProcessRotc.Insert(amin, amax, { i, loca });
		GraphG_Location_AfterPreProcessRotc.push_back(loca);
	}
	swap(GraphG_AfterPreProcessRotc, NewSubGraph);
	ROTCvarify_kcore(nq, k, GraphG_AfterPreProcessRotc, L_Degree, bin, pos, vert);//input k is kBound[1]

	Results.resize(GraphG_AfterPreProcessRotc.size(), true);
	VGk.resize(GraphG_AfterPreProcessRotc.size(), true);

#ifdef DEBUG
	cout << "L_Degree[nq] : " << L_Degree[nq] << endl;
#endif
}


unsigned RoctPlus::PreProcess(unsigned Height, unsigned k, float r)
{
	unsigned times = 0;
	vector<pair<pair<float, float>, float>> Y({ { GraphG_Location_AfterPreProcessRotc[q], r } }); // (CircleCenter, Radius)
	vector<pair<pair<float, float>, float>> Yc;// (CircleCenter, Radius)
	vector<bool> S(GraphG_AfterPreProcessRotc.size(), true);
	vector<vector<unsigned>> NewGraph;
	vector<unsigned> Connect;

	while (times++ != Height)
	{
		while (!Y.empty())//partition circle of Y into four groups with size �� �� �� and put them into Yc (�� = r / 2)
		{
			pair<pair<float, float>, float> circle = Y.back();
			Y.pop_back();
			CutCircle(circle, Yc);
		}

		while (!Yc.empty())//construct graph G(X) using X which contains vertices enclosed in O(c, r + ��2 / 2 * ��)
		{
			pair<pair<float, float>, float> circle = Yc.back();
			Yc.pop_back();
			if (distance(circle.first, GraphG_Location_AfterPreProcessRotc[q]) > circle.second * SQR2 + r)
			{
				continue;
			}
			overloadedSearch.SearchEdgeNoDegree(circle.first, circle.second * SQR2 + r, RTree_AfterPreProcessRotc, NewGraph, CandidateGk,
				Gk_OldNew, GraphG_AfterPreProcessRotc);
			auto nq = Gk_OldNew[q];
			if (ROTCvarify_kcore(nq, k, NewGraph, L_Degree, bin, pos, vert))
			{
				ConnectedGraphGet(k, nq, L_Degree, NewGraph, Connect);
				float&& Radius = MinimumExternalCircle(Connect, GraphG_Location_AfterPreProcessRotc);
				if (Radius <= r + 0.0001)//exists a RB-k-core in this
				{
					//set Results[i] false using the vertices in Connect 
					for_each(std::execution::par, Connect.begin(), Connect.end(), [&](unsigned i) {Results[i] = false;});
				}
				else// exists a k-core in this
				{
					Y.push_back(circle);
					for_each(std::execution::par, Connect.begin(), Connect.end(), [&](unsigned i) {S[i] = false; }); //put vertices in V (G(X)k) into S
				}

			}
		}

		//  Set VGk[i] false if S[i] is false
		for (unsigned i = 0; i != S.size(); ++i)
		{
			if (S[i])
			{
				VGk[i] = false;
			}
			else
			{
				S[i] = true;
			}
		}
	}

#ifdef DEBUG
	cout << "no result and no cut vertices : ";
#endif

	for(unsigned i = 0; i != VGk.size(); ++i)
	{
		if (!Results[i])
		{
			VerticesCount++;
		}
		else if (!VGk[i] && Results[i])
		{
			CutVerticesCount++;
		}
#ifdef DEBUG
		else if(VGk[i] && Results[i])
		{
			cout << i << ",";
		}
		if(i == VGk.size() - 1)
		{
			cout << endl;
		}
#endif
	}


	return VerticesCount;
}




bool RoctPlus::PoleVarify(unsigned u, float r, unsigned k, vector<vector<unsigned>>& ExNewGraph, vector<unsigned>& Connect)
{
	unsigned&& newnumber = overloadedSearch.SearchPoleVarify( GraphG_Location_AfterPreProcessRotc[u], r * 2, RTree_AfterPreProcessRotc, VGk, Results, ExNewGraph, CandidateGk, GraphG_AfterPreProcessRotc);
	if (newnumber == 0)
		return false;
	if (ROTCvarify_kcore(Gk_OldNew[q], k, ExNewGraph, L_Degree, bin, pos, vert))
	{
		ConnectedGraphGet(k, Gk_OldNew[q], L_Degree, ExNewGraph, Connect);
		float&& Radius = MinimumExternalCircle(Connect, GraphG_Location_AfterPreProcessRotc);
		if (Radius <= r + 0.0001)//exists a RB-k-core in this
		{
			//set Results[i] false using the vertices in Connect 
			for_each(std::execution::par, Connect.begin(), Connect.end(), [&](unsigned i) { if (Results[i]) {
				Results[i] = false; 
				VerticesCount++;
			} });
			return false;
		}
		else
		{
			return true;
		}
	}
	else
	{
		return false;
	}

}

double&& calatan2(double x, double y) {
	double&& result = atan2l(y, x) * 180 / M_PI;
	if (result < 0)
	{
		return result + 360.0;
	}
	return std::move(result);
}
void BinaryVerticesBoundedCircle(double x1, double y1, double x2, double y2, double R, double
	& rx0, double& ry0, double& rx1, double& ry1, double& cx0, double& cx1)//compute Wr(u, v) using {u, v} and r
{
	double&& c1 = (x2 * x2 - x1 * x1 + y2 * y2 - y1 * y1) / (2 * (x2 - x1));
	double&& c2 = (y2 - y1) / (x2 - x1);  //б��
	double&& A = (c2 * c2 + 1);
	double&& B = (2 * x1 * c2 - 2 * c1 * c2 - 2 * y1);
	double&& C = x1 * x1 - 2 * x1 * c1 + c1 * c1 + y1 * y1 - R * R;

	ry0 = (-B + sqrt(B * B - 4 * A * C)) / (2 * A);
	rx0 = c1 - c2 * ry0;
	cx0 = calatan2(rx0 - x1, ry0 - y1);

	ry1 = (-B - sqrt(B * B - 4 * A * C)) / (2 * A);
	rx1 = c1 - c2 * ry1;
	cx1 = calatan2(rx1 - x1, ry1 - y1);
}

unsigned RoctPlus::RotcPlusMain(float r, unsigned k)
{	
	vector<vector<unsigned>> NewGraph;
	vector<unsigned> Connect;
	vector<pair<double, pair<double, double>>> C;
	C.reserve(GraphG_AfterPreProcessRotc.size() * 2);

	auto start = high_resolution_clock::now();

	vector<unsigned> NeVertices{};
	for(unsigned u = 0; u != VGk.size(); ++u)
	{
		C.clear();
		/**/
		//cpu time
		auto end = std::chrono::high_resolution_clock::now();
		//end - start   ms
		auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
		//time out
		if (duration.count() > 100000)
		{
			cout << "time out Just Size" << endl;
			return VerticesCount + GraphG_AfterPreProcessRotc.size() / 50;
		}

		if (VerticesCount + CutVerticesCount >= GraphG_AfterPreProcessRotc.size() - GraphG_AfterPreProcessRotc.size()/25)
		{
			return VerticesCount + GraphG_AfterPreProcessRotc.size() / 50;
		}
		if (VGk[u])// if (true) : not be prune by (Grouping-Based Pre-process) or (PoleVarify)
		{
			if (!PoleVarify(u, r, k, NewGraph, Connect))
			{
				VGk[u] = false;
				if(Results[u])
				{
					CutVerticesCount++;
				}
				continue;
			}
			swap(NeVertices, CandidateGk);
			for (unsigned& v : NeVertices)
			{
				if (v <= u || !VGk[v])
					continue;
				double&& distances = distance(GraphG_Location_AfterPreProcessRotc[u], GraphG_Location_AfterPreProcessRotc[v]);

				//compute Wr(u, v) using {u, v} and r, put circles in Wr(u, v) into C
				if(distances < 2 * r - 0.01)
				{
					pair<double, pair<double, double>> xy0{ 0,{0,0} };
					pair<double, pair<double, double>> xy1{ 0,{0,0} };
					BinaryVerticesBoundedCircle(GraphG_Location_AfterPreProcessRotc[u].first, GraphG_Location_AfterPreProcessRotc[u].second,
						GraphG_Location_AfterPreProcessRotc[v].first, GraphG_Location_AfterPreProcessRotc[v].second, r,
						xy0.second.first, xy0.second.second, xy1.second.first, xy1.second.second, xy0.first, xy1.first);
					if (distance(GraphG_Location_AfterPreProcessRotc[q], xy0.second) <= r)
						C.push_back(xy0);
					if (distance(GraphG_Location_AfterPreProcessRotc[q], xy1.second) <= r)
						C.push_back(xy1);
				}
				else
				{
					pair<float, pair<float, float>> xy{ 0,{0,0} };
					xy.second.first = (GraphG_Location_AfterPreProcessRotc[u].first + GraphG_Location_AfterPreProcessRotc[v].first) / 2.0;
					xy.second.second = (GraphG_Location_AfterPreProcessRotc[u].second + GraphG_Location_AfterPreProcessRotc[v].second) / 2.0;
					xy.first = calatan2(xy.second.first - GraphG_Location_AfterPreProcessRotc[u].first, xy.second.second - GraphG_Location_AfterPreProcessRotc[u].second);
					if (distance(GraphG_Location_AfterPreProcessRotc[q], xy.second) <= r)
						C.push_back(xy);
				}
			}
			//sort C in ascending order of centers�� polar angles
			//sort C in ascending order of C.first
			std::sort(std::execution::par, C.begin(), C.end(), [](const pair<double, pair<double, double>>& a, const pair<double, pair<double, double>>& b) {return a.first < b.first; });
			C.erase(unique(std::execution::par, C.begin(), C.end(), [](const pair<double, pair<double, double>>& a, const pair<double, pair<double, double>>& b) {return (b.first - a.first) < 0.01; }), C.end());

			for (auto& [angle, Center] : C)
			{
				float&& distances = distance(GraphG_Location_AfterPreProcessRotc[q], Center);
				if (distances < r - 0.0001)
				{
					continue;
				}

				//CandidateGk �� a set of vertices enclosed in O(c, r)   //construct G(CandidateGk) from CandidateGk
				unsigned&& newnumber = overloadedSearch.SearchPoleVarify(Center, r, RTree_AfterPreProcessRotc, VGk, Results, NewGraph, CandidateGk, GraphG_AfterPreProcessRotc);
				if (newnumber != 0)
				{
					//varify RB-k-core
					if (ROTCvarify_kcore(Gk_OldNew[q], k, NewGraph, L_Degree, bin, pos, vert))
					{
						ConnectedGraphVarify(k, Gk_OldNew[q], L_Degree, NewGraph, Results, VerticesCount);
					}
				}
			}
		}
	}
	return VerticesCount;

}

unsigned RoctPlus::RotcPlusPenaty(float r, unsigned k, unsigned CurrentbestPenaty)
{
	vector<vector<unsigned>> NewGraph;
	vector<unsigned> Connect;
	vector<pair<double, pair<double, double>>> C;
	C.reserve(GraphG_AfterPreProcessRotc.size() * 2);

	vector<unsigned> NeVertices{};

	auto start = std::chrono::high_resolution_clock::now();
	for (unsigned u = 0; u != VGk.size(); ++u)
	{
		C.clear();
		/**/
//cpu time
		auto end = std::chrono::high_resolution_clock::now();
		//end - start   ms
		auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
		//time out
		if (duration.count() > 1000)//00
		{
			cout << "time out penalty varify" << endl;
			return VerticesCount + GraphG_AfterPreProcessRotc.size() / 50;
		}

		if (VerticesCount + CutVerticesCount >= GraphG_AfterPreProcessRotc.size() - GraphG_AfterPreProcessRotc.size()/25)
		{
			return VerticesCount + GraphG_AfterPreProcessRotc.size() / 50;
		}
		if (VerticesCount > CurrentbestPenaty)
		{
			return CurrentbestPenaty;
		}

		if (VGk[u])// if (true) : not be prune by (Grouping-Based Pre-process) or (PoleVarify)
		{
			if (!PoleVarify(u, r, k, NewGraph, Connect))
			{
				VGk[u] = false;
				if (Results[u])
				{
					CutVerticesCount++;
				}
				continue;
			}
			swap(NeVertices, CandidateGk);
			for (unsigned& v : NeVertices)
			{
				if (v <= u || !VGk[v])
					continue;
				double&& distances = distance(GraphG_Location_AfterPreProcessRotc[u], GraphG_Location_AfterPreProcessRotc[v]);

				//compute Wr(u, v) using {u, v} and r, put circles in Wr(u, v) into C
				if (distances < 2 * r - 0.01)
				{
					pair<double, pair<double, double>> xy0{ 0,{0,0} };
					pair<double, pair<double, double>> xy1{ 0,{0,0} };
					BinaryVerticesBoundedCircle(GraphG_Location_AfterPreProcessRotc[u].first, GraphG_Location_AfterPreProcessRotc[u].second,
						GraphG_Location_AfterPreProcessRotc[v].first, GraphG_Location_AfterPreProcessRotc[v].second, r,
						xy0.second.first, xy0.second.second, xy1.second.first, xy1.second.second, xy0.first, xy1.first);
					if (distance(GraphG_Location_AfterPreProcessRotc[q], xy0.second) <= r)
						C.push_back(xy0);
					if (distance(GraphG_Location_AfterPreProcessRotc[q], xy1.second) <= r)
						C.push_back(xy1);
				}
				else
				{
					pair<float, pair<float, float>> xy{ 0,{0,0} };
					xy.second.first = (GraphG_Location_AfterPreProcessRotc[u].first + GraphG_Location_AfterPreProcessRotc[v].first) / 2.0;
					xy.second.second = (GraphG_Location_AfterPreProcessRotc[u].second + GraphG_Location_AfterPreProcessRotc[v].second) / 2.0;
					xy.first = calatan2(xy.second.first - GraphG_Location_AfterPreProcessRotc[u].first, xy.second.second - GraphG_Location_AfterPreProcessRotc[u].second);
					if (distance(GraphG_Location_AfterPreProcessRotc[q], xy.second) <= r)
						C.push_back(xy);
				}
			}
			//sort C in ascending order of centers�� polar angles
			//sort C in ascending order of C.first
			std::sort(std::execution::par, C.begin(), C.end(), [](const pair<double, pair<double, double>>& a, const pair<double, pair<double, double>>& b) {return a.first < b.first; });
			C.erase(unique(std::execution::par, C.begin(), C.end(), [](const pair<double, pair<double, double>>& a, const pair<double, pair<double, double>>& b) {return (b.first - a.first) < 0.01; }), C.end());

			for (auto& [angle, Center] : C)
			{
				double&& distances = distance(GraphG_Location_AfterPreProcessRotc[q], Center);
				if (distances < r)
				{
					continue;
				}
				//CandidateGk �� a set of vertices enclosed in O(c, r)   //construct G(CandidateGk) from CandidateGk
				unsigned&& newnumber = overloadedSearch.SearchPoleVarify(Center, r, RTree_AfterPreProcessRotc, VGk, Results, NewGraph, CandidateGk, GraphG_AfterPreProcessRotc);
				if (newnumber != 0)
				{

					//varify RB-k-core
					if (ROTCvarify_kcore(Gk_OldNew[q], k, NewGraph, L_Degree, bin, pos, vert))
					{
						ConnectedGraphVarify(k, Gk_OldNew[q], L_Degree, NewGraph, Results, VerticesCount);
						if (VerticesCount > CurrentbestPenaty)
						{
							return CurrentbestPenaty;
						}
					}
				}
			}
		}
	}
	return VerticesCount;
}

void CutCircle(pair<pair<float, float>, float>& circle, vector<pair<pair<float, float>, float>>& Yc)
{
	float&& r = circle.second / 2.0;
	float x = circle.first.first;
	float y = circle.first.second;
	//Divide the circle into four equal parts
	float&& x1 = x - r;
	float&& x2 = x + r;
	float&& y1 = y - r;
	float&& y2 = y + r;
	Yc.push_back({ {x1, y1}, r });
	Yc.push_back({ {x1, y2}, r });
	Yc.push_back({ {x2, y1}, r });
	Yc.push_back({ {x2, y2}, r });

}

void ConnectedGraphVarify(unsigned k, unsigned q, vector<int>& L_Degree, const vector<vector<unsigned>>& Gx, vector<bool>& Result, unsigned & VerticesCount)
{
	vector<bool> FindOrNot(L_Degree.size(), false);
	vector<unsigned> WaitToFind;
	WaitToFind.reserve(Gx.size());
	WaitToFind.push_back(q);
	FindOrNot[q] = true;
	while (!WaitToFind.empty())
	{
		unsigned&& temp = std::move(WaitToFind.back());
		WaitToFind.pop_back();
		if(Result[CandidateGk[temp]])
		{
			Result[CandidateGk[temp]] = false;
			++VerticesCount;
		}
		for (auto& nei : Gx[temp])
		{
			if (FindOrNot.at(nei) == false)
			{
				FindOrNot[nei] = true;
				if (L_Degree[nei] >= k)
				{
					WaitToFind.push_back(nei);
				}
			}
		}
	}

}



bool ROTCvarify_kcore(int q, int k, const vector<vector<unsigned>>& Gx, vector<int>& L_Degree, vector<int>& bin, vector<int>& pos
	, vector<int>& vert)
{
	L_Degree.clear();
	pos.clear();
	bin.clear();
	int n = Gx.size();
	int Md = 0;//Md�������ڵ�ȣ����Թ���bin�Ĵ�С��
	//��L_Degree�в���ڵ��ھӸ����������±��Ƕ�Ӧ������ID
	L_Degree.reserve(n);
	int i = 0;
	for (const auto& a : Gx)
	{
		int sizee = a.size();
		L_Degree.push_back(sizee);
		Md = max(Md, sizee);
	}
	bin.resize(Md + 1, 0);
	for (int i = 0; i != n; ++i)
	{
		++bin[L_Degree[i]];
	}
	int start = 0;
	int num = 0;
	for (int d = 0; d != Md + 1; ++d)
	{
		num = bin[d];
		bin[d] = start;
		start += num;
	}
	pos.reserve(n);
	vert.resize(n);
	for (int i = 0; i != n; ++i)
	{
		pos.push_back(bin[L_Degree[i]]++);
		vert[pos[i]] = i;
	}
	for (int d = Md; d != 0; --d)
	{
		bin[d] = bin[d - 1];
	}
	bin[0] = 0;
	for (int i = 0; i != n; ++i)
	{
		int v = vert[i];
		if (L_Degree[v] >= k)
		{
			return true;
		}
		if (L_Degree[q] < k)
		{
			return false;
		}
		auto& Neis = Gx[v];
		for (auto& u : Neis)
		{

			if (L_Degree[u] > L_Degree[v])
			{
				int du = L_Degree[u];
				int pu = pos[u];
				int pw = bin[du];
				int w = vert[pw];
				if (u != w)
				{
					pos[u] = pw;
					vert[pu] = w;
					pos[w] = pu;
					vert[pw] = u;
				}
				++bin[du];
				--L_Degree[u];
			}
		}
	}
	//cout << "core number veritf all" << endl;
	return false;
	/*for(auto a : L_Degree)
	{
		cout << a << " " ;
	}*/
}

