#pragma once
#include "K_PreProcess.h"
#include <queue>

typedef pair<float, float> LocationType;

void varify_kcore(unsigned q, unsigned m, const vector<vector<unsigned>>& Gx, vector<int>& L_Degree, vector<int>& bin, vector<int>& pos
	, vector<int>& vert);
void TheBiggestK(unsigned Begin, unsigned Beginm, unsigned& kmax, unsigned& kmin, vector<unsigned>& FindOrNot, vector<deque<unsigned>>& WaitingList, const vector<vector<unsigned>>& Gx
	, vector<int>& L_Degree, unsigned f, unsigned inse, vector<int>& Connect);
void TheBiggestKNoconnect(unsigned Begin, unsigned& kmax, unsigned& kmin, vector<unsigned>& FindOrNot, vector<vector<unsigned>>& WaitingList, const vector<vector<unsigned>>& Gx
	, vector<int>& L_Degree, unsigned f, unsigned inse, unsigned anf, unsigned aninse, bool& end);
unsigned ConnectedVarifytest(unsigned kpre, unsigned q, unsigned m, vector<int>& L_Degree, vector<int>& bin, const vector<vector<unsigned>>& Gx, vector<int>& Connect);
unsigned ConnectedVarifyNoconnect(unsigned q, unsigned m, vector<int>& L_Degree, vector<int>& bin, const vector<vector<int>>& Gx);
unsigned ConnectedVarifyNoconnecttest(unsigned kpre, unsigned q, unsigned m, vector<int>& L_Degree, vector<int>& bin, const vector<vector<unsigned>>& Gx);
float MinimumExternalCircle(vector<int>& Connect, vector<pair<float, float>>& GraphG_Location_AfterPreProcess);
float MinimumExternalCircle(vector<unsigned>& Connect, vector<pair<float, float>>& GraphG_Location_AfterPreProcess);
float MinimumExternalCirclePrecision(vector<unsigned>& Connect, const vector<pair<float, float>>& GraphG_Location_AfterPreProcess);
float MinimumExternalCirclePrecision(vector<int>& Connect, const vector<pair<float, float>>& GraphG_Location_AfterPreProcess);


//α�����е�N
struct AfterPruning
{
	AfterPruning()
	{
	}
	unsigned km;//the biggest value of km of connected km-core contianing both m and q
	vector<int> degree;
	pair<LocationType, LocationType> boundingbox;

	friend bool operator < (AfterPruning a, AfterPruning b)
	{
		return a.km > b.km;    //����С�ں�ʹ�ô����ǰ
	}

};

struct Point2D {
	Point2D() {};
	Point2D(float a, float b)
	{
		x = a;
		y = b;
	}
	float x;
	float y;
};

class K_PrePruning
{

public:
	inline vector<AfterPruning>& GetAllAfterPruning() { return AllAfterPruning; }
	void QuadtreeDivision(unsigned Height);
	void BetterQuadtreeDivision(unsigned Height, vector<Point2D> rectengals);
	unsigned Prepruning(unsigned kprime, unsigned nq, unsigned nm, float r, unsigned Height, vector<vector<unsigned>>& GraphG_AfterPreProcess,
		vector<pair<float, float>>& GraphG_Location_AfterPreProcess, MyTree& REdgeTree_GAfterPreProcess, OverloadedSearch& overloadedSearch);
	unsigned PrepruningIndex(unsigned kprime, unsigned nq, unsigned nm, float r, unsigned Height, vector<vector<unsigned>>& GraphG_AfterPreProcess,
		vector<pair<float, float>>& GraphG_Location_AfterPreProcess, MyTree& RTree_AfterPreProcess, OverloadedSearch& overloadedSearch, const vector<vector<int> >& AfterProLeverCoreness);
private:

	queue<pair<LocationType, LocationType>> T;
	vector<AfterPruning> AllAfterPruning;

};

void K_PrePruning::QuadtreeDivision(unsigned Height)
{
	pair<LocationType, LocationType> temp;
	while (Height-- != 0)
	{
		unsigned count = T.size();
		for (unsigned i = 0; i != count; ++i)
		{
			temp = T.front();
			T.pop();
			float xmin = temp.first.first;
			float ymin = temp.first.second;
			float xmax = temp.second.first;
			float ymax = temp.second.second;
			float xmid = (temp.first.first + temp.second.first) / 2.0;
			float ymid = (temp.first.second + temp.second.second) / 2.0;
			//Upper left corner
			T.push({ {xmin, ymid} ,{xmid, ymax} });
			//Upper Right corner
			T.push({ {xmid, ymid} ,{xmax, ymax} });
			//Lower left corner
			T.push({ {xmin, ymin} ,{xmid, ymid} });
			//Lower Right corner
			T.push({ {xmid, ymin} ,{xmax, ymid} });
		}
	}
}


/**/
unsigned K_PrePruning::Prepruning(unsigned kprime, unsigned nq, unsigned nm, float r, unsigned Height, vector<vector<unsigned>>& GraphG_AfterPreProcess,
	vector<pair<float, float>>& GraphG_Location_AfterPreProcess, MyTree& RTree_AfterPreProcess, OverloadedSearch& overloadedSearch)
{
	unsigned kpre = kprime;

	// initialize the quadtree with the bounding box of the two nodes
	float min[] = { std::max(GraphG_Location_AfterPreProcess[nq].first, GraphG_Location_AfterPreProcess[nm].first) - r,
	std::max(GraphG_Location_AfterPreProcess[nq].second, GraphG_Location_AfterPreProcess[nm].second) - r };
	float max[] = { std::min(GraphG_Location_AfterPreProcess[nq].first, GraphG_Location_AfterPreProcess[nm].first) + r,
		std::min(GraphG_Location_AfterPreProcess[nq].second, GraphG_Location_AfterPreProcess[nm].second) + r };
	T.push({ { min[0],min[1] }, { max[0],max[1] } });
	//Create Quadtree with "Height" levels of height
	QuadtreeDivision(Height);

	//varify begin
	vector<vector<unsigned>> NewGraph;
	pair<LocationType, LocationType> t;
	vector<int> Connect;
	Connect.reserve(GraphG_Location_AfterPreProcess.size());
	vector<int> L_Degree;
	vector<int> bin;
	vector<int> pos;
	vector<int> vert;
	unsigned nnq, nnm;
	while (!T.empty())
	{
		t = T.front();
		T.pop();
		pair<float,float> CircleCenter = { (t.first.first + t.second.first) / 2.0, (t.first.second + t.second.second) / 2.0 };
		float CircleRadius = hypot(t.second.second - t.first.second, t.second.first - t.first.first) / 2.0 + r;
		overloadedSearch.SearchEdgeNoDegree(CircleCenter, CircleRadius, RTree_AfterPreProcess, NewGraph, CandidateGk, Gk_OldNew, GraphG_AfterPreProcess);
		nnq = Gk_OldNew[nq];
		nnm = Gk_OldNew[nm];
		varify_kcore(nnq, nnm, NewGraph, L_Degree, bin, pos, vert);
		//�ж���������Ƿ���Ҫ���� �͵�ǰkpro�Ƚ�
		unsigned  mayreach = std::min(L_Degree[nnq], L_Degree[nnm]);
		if (mayreach <= kpre)
		{
			//std::cout << "cut" << std::endl;
			continue;//�޼����������
		}
		//Get km after varify connected km-core
		unsigned km = 0;
		//km = ConnectedVarify(nq, nm, L_Degree, bin, NewGraph, Connect);
		km = ConnectedVarifytest(kpre, nnq, nnm, L_Degree, bin, NewGraph, Connect);
		//insert AfterPruning to AllAfterPruning
		float RadiusAndCenter = MinimumExternalCircle(Connect, GraphG_Location_AfterPreProcess);
		Connect.clear();
		if (RadiusAndCenter <= r)
		{
			kpre = std::max(kpre, km);
		}
		if (km <= mayreach && km > kpre && RadiusAndCenter > r)
		{
			AfterPruning ap;
			AllAfterPruning.push_back(ap);
			auto a = --AllAfterPruning.end();
			a->km = km;
			a->degree.resize(GraphG_AfterPreProcess.size(), 0);
			for (unsigned j = 0; j != L_Degree.size(); ++j)
			{
				a->degree[CandidateGk[j]] = std::move(L_Degree[j]);
			}
			//swap(a->Graph, NewGraph);
			a->boundingbox = t;
		}
	}
	std::sort(AllAfterPruning.begin(), AllAfterPruning.end());
	return kpre;
}


float dist(const Point2D& p1, const Point2D& p2)
{
	return sqrt(pow(p1.x - p2.x, 2) + pow(p1.y - p2.y, 2));
}
vector<Point2D> intersectionofcircles(const Point2D& C1, const float& R1, const Point2D& C2, const float& R2)
{
	vector<Point2D> i_Result; i_Result.clear();
	float d = dist(C1, C2);//Բ�ľ�d
	if (abs(d) < 1e-5) {}//�غϣ����ؿ�
	else//���غϣ�����a
	{
		float a = (d * d + R1 * R1 - R2 * R2) / (2 * d);
		if (abs(a * a - R1 * R1) < 1e-5)//����
		{
			/*
			Point2D target;
			double t = R1 / d;
			target[0] = C1[0] * (1 - t) + C2[0] * t;
			target[1] = C1[1] * (1 - t) + C2[1] * t;
			i_Result.push_back(target);*/
		}
		else if (a * a < R1 * R1)//�ཻ
		{
			float h = pow((R1 * R1 - a * a), 0.5f);
			//C1->C2�ĵ�λ������������
			Point2D Dv((C2.x - C1.x) / d, (C2.y - C1.y) / d);
			//C1->C2�ĵ�λ����������
			Point2D Nv;
			if (Dv.x == 0)
			{
				Nv.x = 1;
				Nv.y = 0;
			}
			else if (Dv.y == 0)
			{
				Nv.x = 0;
				Nv.y = 1;
			}
			else
			{
				Nv.x = -1 / Dv.x;
				Nv.y = 1 / Dv.y;
				float unify = sqrt(Nv.x * Nv.x + Nv.y * Nv.y);
				Nv.x = Nv.x / unify;
				Nv.y = Nv.y / unify;
			}

			Point2D p1, p2;
			p1.x = C1.x + a * Dv.x + h * Nv.x;
			p1.y = C1.y + a * Dv.y + h * Nv.y;
			p2.x = C1.x + a * Dv.x - h * Nv.x;
			p2.y = C1.y + a * Dv.y - h * Nv.y;
			i_Result.push_back(p1);
			i_Result.push_back(p2);
		}
		else//a*a>R1*R1,����
		{
		}
	}
	return i_Result;
}
vector<Point2D> GetRectengals(pair<float, float> Cir1, pair<float, float> Cir2, float radius)
{
	Point2D C1(Cir1.first, Cir1.second);
	Point2D C2(Cir2.first, Cir2.second);
	float r = radius;

	vector<Point2D> P2D;
	P2D = intersectionofcircles(C1, r, C2, r);
	if (P2D.empty())
	{
		return P2D;
	}
	Point2D mid((C1.x + C2.x) / 2, (C1.y + C2.y) / 2);
	float d = dist(C1, C2);
	float minx = min(C1.x, C2.x);
	float miny = min(C1.y, C2.y);
	float dx, dy;
	float ratio = (d - r) / d;
	Point2D U1;
	Point2D U2;
	float k1, k2;
	if (C2.x >= C1.x)
	{
		dx = C2.x - C1.x;
		dy = C2.y - C1.y;
		U1.x = C1.x + dx * ratio;
		U1.y = C1.y + dy * ratio;
		U2.x = C2.x - dx * ratio;
		U2.y = C2.y - dy * ratio;
	}
	else
	{
		dx = C1.x - C2.x;
		dy = C1.y - C2.y;
		U1.x = C2.x + dx * ratio;
		U1.y = C2.y + dy * ratio;
		U2.x = C1.x - dx * ratio;
		U2.y = C1.y - dy * ratio;
	}
	k1 = dy / dx;
	k2 = mid.y - P2D[0].y / mid.x - P2D[0].x;
	vector<float> B(4, 0);
	B[0] = P2D[0].y - k1 * P2D[0].x;
	B[1] = P2D[1].y - k1 * P2D[1].x;
	B[2] = U1.y - k2 * U1.x;
	B[3] = U2.y - k2 * U2.x;

	vector<Point2D> Rectangles;
	for (unsigned i = 0; i != 2; i++)
	{
		for (unsigned j = 2; j != 4; ++j)
		{
			float x = (B[j] - B[i]) / (k1 - k2);
			float y = k1 * x + B[i];
			Rectangles.push_back(Point2D(x, y));
		}
	}

	return Rectangles;
}


unsigned K_PrePruning::PrepruningIndex(unsigned kprime, unsigned nq, unsigned nm, float r, unsigned Height, vector<vector<unsigned>>& GraphG_AfterPreProcess,
	vector<pair<float, float>>& GraphG_Location_AfterPreProcess, MyTree& RTree_AfterPreProcess, OverloadedSearch& overloadedSearch, const vector<vector<int> >& AfterProLeverCoreness)
{
	unsigned kpre = kprime;
	
	// initialize the quadtree with the bounding box of the two nodes
	/*
	float min[] = { std::max(GraphG_Location_AfterPreProcess[nq].first, GraphG_Location_AfterPreProcess[nm].first) - r,
	std::max(GraphG_Location_AfterPreProcess[nq].second, GraphG_Location_AfterPreProcess[nm].second) - r };
	float max[] = { std::min(GraphG_Location_AfterPreProcess[nq].first, GraphG_Location_AfterPreProcess[nm].first) + r,
		std::min(GraphG_Location_AfterPreProcess[nq].second, GraphG_Location_AfterPreProcess[nm].second) + r };
	T.push({ { min[0],min[1] }, { max[0],max[1] } });*/
	//Create Quadtree with "Height" levels of height
	//QuadtreeDivision(Height);
	vector<Point2D> rec = GetRectengals(GraphG_Location_AfterPreProcess[nq], GraphG_Location_AfterPreProcess[nm], r);
	if (rec.empty())
	{
		return 0;
	}
	T.push({ { rec[0].x,rec[0].y }, { rec[3].x,rec[3].y } });
	BetterQuadtreeDivision(Height, rec);

	//varify begin
	vector<vector<unsigned>> NewGraph;
	pair<LocationType, LocationType> t;
	vector<int> Connect;
	Connect.reserve(GraphG_Location_AfterPreProcess.size());
	vector<int> L_Degree;
	vector<int> bin;
	vector<int> pos;
	vector<int> vert;
	unsigned nnq, nnm;
	while (!T.empty())
	{
		t = T.front();
		T.pop();
		pair<float, float> CircleCenter = { (t.first.first + t.second.first) / 2.0, (t.first.second + t.second.second) / 2.0 };
		float CircleRadius = hypot(t.second.second - t.first.second, t.second.first - t.first.first) / 2.0 + r;
		if (distance(CircleCenter, GraphG_Location_AfterPreProcess[nq]) > CircleRadius || distance(CircleCenter, GraphG_Location_AfterPreProcess[nm]) > CircleRadius)
		{
			continue;
		}
		if (overloadedSearch.SearchEdgeNoDegreeIndex(nq, nm, kpre, CircleCenter, CircleRadius, RTree_AfterPreProcess, NewGraph, CandidateGk, Gk_OldNew, GraphG_AfterPreProcess, AfterProLeverCoreness) == 0)
		{
			continue;//pruning
		}
		nnq = Gk_OldNew[nq];
		nnm = Gk_OldNew[nm];
		varify_kcore(nnq, nnm, NewGraph, L_Degree, bin, pos, vert);
		//�ж���������Ƿ���Ҫ���� �͵�ǰkpro�Ƚ�
		unsigned  mayreach = std::min(L_Degree[nnq], L_Degree[nnm]);
		if (mayreach <= kpre)
		{
			//std::cout << "cut" << std::endl;
			continue;//�޼����������
		}
		//Get km after varify connected km-core
		unsigned km = 0;
		//km = ConnectedVarify(nq, nm, L_Degree, bin, NewGraph, Connect);
		km = ConnectedVarifytest(kpre, nnq, nnm, L_Degree, bin, NewGraph, Connect);
		//insert AfterPruning to AllAfterPruning
		float RadiusAndCenter = MinimumExternalCircle(Connect, GraphG_Location_AfterPreProcess);
		//float RadiusAndCenter = MinimumExternalCirclePrecision(Connect, GraphG_Location_AfterPreProcess);
		if (RadiusAndCenter <= r)
		{
			kpre = std::max(kpre, km);
		}
		if (km <= mayreach && km > kpre && RadiusAndCenter > r)
		{
			AfterPruning ap;
			AllAfterPruning.push_back(ap);
			auto a = --AllAfterPruning.end();
			a->km = km;
			a->degree.resize(GraphG_AfterPreProcess.size(), 0);
			/*
			for (unsigned j = 0; j != L_Degree.size(); ++j)
			{
				a->degree[CandidateGk[j]] = std::move(L_Degree[j]);
			}*/
			for (auto& i : Connect)
			{
				a->degree[i] = std::move(L_Degree[Gk_OldNew[i]]);
			}
			//swap(a->Graph, NewGraph);
			a->boundingbox = t;
			Connect.clear();
		}
	}
	std::sort(AllAfterPruning.begin(), AllAfterPruning.end());
	return kpre;
}

void K_PrePruning::BetterQuadtreeDivision(unsigned Height, vector<Point2D> rectengal)
{
	pair<LocationType, LocationType> temp;
	queue<vector<Point2D>> rectengals;
	rectengals.push(rectengal);
	vector<Point2D>& temp1 = rectengals.front();
	while (Height-- != 0)
	{
		unsigned count = T.size();
		for (unsigned i = 0; i != count; ++i)
		{
			temp1 = rectengals.front();
			temp = T.front();
			T.pop();
			float xmid = (temp.first.first + temp.second.first) / 2.0;
			float ymid = (temp.first.second + temp.second.second) / 2.0;
			Point2D mid(xmid, ymid);
			Point2D mid01((temp1[0].x + temp1[1].x) / 2.0, (temp1[0].y + temp1[1].y) / 2.0);
			Point2D mid02((temp1[0].x + temp1[2].x) / 2.0, (temp1[0].y + temp1[2].y) / 2.0);
			Point2D mid13((temp1[1].x + temp1[3].x) / 2.0, (temp1[1].y + temp1[3].y) / 2.0);
			Point2D mid23((temp1[2].x + temp1[3].x) / 2.0, (temp1[2].y + temp1[3].y) / 2.0);
			vector<Point2D> r0 = { temp1[0], mid01, mid02, mid };
			vector<Point2D> r1 = { mid01, temp1[1], mid, mid13 };
			vector<Point2D> r2 = { mid02, mid, temp1[2], mid23 };
			vector<Point2D> r3 = { mid, mid13, mid23, temp1[3] };
			T.push({ {xmid, ymid} ,{temp1[0].x, temp1[0].y} });
			T.push({ {xmid, ymid} ,{temp1[1].x, temp1[1].y} });
			T.push({ {xmid, ymid} ,{temp1[2].x, temp1[2].y} });
			T.push({ {xmid, ymid} ,{temp1[3].x, temp1[3].y} });

			
			rectengals.push(r0);
			rectengals.push(r1);
			rectengals.push(r2);
			rectengals.push(r3);
			rectengals.pop();
		}
	}
}


float MinimumExternalCircle(vector<int>& Connect, vector<pair<float, float>>& GraphG_Location_AfterPreProcess)
{
	float&& leftx = 65555;
	float&& downy = 65555;
	float&& rightx = -65555;
	float&& upy = -65555;

	for (const int& vertex : Connect) {
		if (GraphG_Location_AfterPreProcess[vertex].first < leftx)
			leftx = GraphG_Location_AfterPreProcess[vertex].first;
		else
			rightx = max(rightx, GraphG_Location_AfterPreProcess[vertex].first);
		if (GraphG_Location_AfterPreProcess[vertex].second < downy)
			downy = GraphG_Location_AfterPreProcess[vertex].second;
		else
			upy = max(upy, GraphG_Location_AfterPreProcess[vertex].second);
	}

	return max(rightx - leftx, upy - downy) / 2.0;
}

float MinimumExternalCircle(vector<unsigned>& Connect, vector<pair<float, float>>& GraphG_Location_AfterPreProcess)
{
	float&& leftx = 65555;
	float&& downy = 65555;
	float&& rightx = -65555;
	float&& upy = -65555;

	for (const int& vertex : Connect) {
		if(GraphG_Location_AfterPreProcess[vertex].first < leftx)
			leftx = GraphG_Location_AfterPreProcess[vertex].first;
		else
			rightx = max(rightx, GraphG_Location_AfterPreProcess[vertex].first);
		if(GraphG_Location_AfterPreProcess[vertex].second < downy)
			downy = GraphG_Location_AfterPreProcess[vertex].second;
		else
			upy = max(upy, GraphG_Location_AfterPreProcess[vertex].second);
	}

	return max(rightx - leftx, upy - downy) / 2.0;
}

float MinimumExternalCirclePrecision(vector<unsigned>& Connect, const vector<pair<float, float>>& GraphG_Location_AfterPreProcess)
{
	float&& leftx = 65555;
	float&& downy = 65555;
	float&& rightx = -65555;
	float&& upy = -65555;

	for (const int& vertex : Connect) {
		if (GraphG_Location_AfterPreProcess[vertex].first < leftx)
			leftx = GraphG_Location_AfterPreProcess[vertex].first;
		else
			rightx = max(rightx, GraphG_Location_AfterPreProcess[vertex].first);
		if (GraphG_Location_AfterPreProcess[vertex].second < downy)
			downy = GraphG_Location_AfterPreProcess[vertex].second;
		else
			upy = max(upy, GraphG_Location_AfterPreProcess[vertex].second);
	}
	return sqrt((rightx - leftx) * (rightx - leftx) + (upy - downy) * (upy - downy)) / 2;
}
float MinimumExternalCirclePrecision(vector<int>& Connect, const vector<pair<float, float>>& GraphG_Location_AfterPreProcess)
{
	float&& leftx = 65555;
	float&& downy = 65555;
	float&& rightx = -65555;
	float&& upy = -65555;

	for (const int& vertex : Connect) {
		if (GraphG_Location_AfterPreProcess[vertex].first < leftx)
			leftx = GraphG_Location_AfterPreProcess[vertex].first;
		else
			rightx = max(rightx, GraphG_Location_AfterPreProcess[vertex].first);
		if (GraphG_Location_AfterPreProcess[vertex].second < downy)
			downy = GraphG_Location_AfterPreProcess[vertex].second;
		else
			upy = max(upy, GraphG_Location_AfterPreProcess[vertex].second);
	}
	return sqrt((rightx - leftx) * (rightx - leftx) + (upy - downy) * (upy - downy)) / 2;
}

void TheBiggestK(unsigned Begin, unsigned Beginm, unsigned& kmax, unsigned& kmin, vector<unsigned>& FindOrNot, vector<deque<unsigned>>& WaitingList, const vector<vector<unsigned>>& Gx
	, vector<int>& L_Degree, unsigned f, unsigned inse, vector<int>& Connect)
{
	//find a connected graph begin to Begin in Gx, and find the biggest k-core of the connected graph
	WaitingList[kmax].push_back(Begin);
	WaitingList[kmax].push_back(Beginm);
	for (unsigned i = kmax; i >= kmin;)
	{
		while (!WaitingList[i].empty())
		{
			unsigned x = WaitingList[i].front();
			WaitingList[i].pop_front();
			Connect.push_back(CandidateGk[x]);
			FindOrNot[x] = f;
			for (auto& nei : Gx[x])
			{
				if (L_Degree[nei] < kmin)
				{
					continue;
				}
				if (FindOrNot[nei] != 0)
				{
					kmin = L_Degree[nei];
				}
				else if (FindOrNot[nei] == 0)
				{
					if (L_Degree[nei] >= i)
					{
						WaitingList[i].push_back(nei);
						FindOrNot[nei] = inse;
					}
					else
					{
						WaitingList[L_Degree[nei]].push_back(nei);
						FindOrNot[nei] = inse;
					}
				}
			}
		}
		if(i < kmin)
			kmax = i;
		--i;
	}
	return;
}

void TheBiggestKsingle(unsigned Begin, unsigned Beginm, unsigned& kmax, unsigned& kmin, vector<unsigned>& FindOrNot, vector<deque<unsigned>>& WaitingList, const vector<vector<unsigned>>& Gx
	, vector<int>& L_Degree, unsigned f, unsigned inse)
{
	//find a connected graph begin to Begin in Gx, and find the biggest k-core of the connected graph
	WaitingList[kmax].push_back(Begin);
	WaitingList[kmax].push_back(Beginm);
	unsigned x = WaitingList[kmax].front();
	WaitingList[kmax].pop_front();
	FindOrNot[x] = f;
	for (auto& nei : Gx[x])
	{
		if (L_Degree[nei] < kmin)
		{
			continue;
		}
		if (FindOrNot[nei] == 0)
		{
			if (L_Degree[nei] >= kmax)
			{
				WaitingList[kmax].push_back(nei);
				FindOrNot[nei] = inse;
			}
			else
			{
				WaitingList[L_Degree[nei]].push_back(nei);
				FindOrNot[nei] = inse;
				kmin = L_Degree[nei];
			}
		}
	}
	for (unsigned i = kmax; i >= kmin; --i)
	{
		while (!WaitingList[i].empty())
		{
			unsigned x = WaitingList[i].front();
			WaitingList[i].pop_front();
			FindOrNot[x] = f;
			for (auto& nei : Gx[x])
			{
				if (L_Degree[nei] < kmin)
				{
					continue;
				}
				if (FindOrNot[nei] != 0)
				{
					if (L_Degree[nei] >= i)
					{
						kmax = i;
						return;
					}
					else
					{
						kmin = L_Degree[nei];
					}
				}
				else if (FindOrNot[nei] == 0)
				{
					if (L_Degree[nei] >= i)
					{
						WaitingList[i].push_back(nei);
						FindOrNot[nei] = inse;
					}
					else
					{
						WaitingList[L_Degree[nei]].push_back(nei);
						FindOrNot[nei] = inse;
					}
				}
			}
		} 
	}
	return;
}

void TheBiggestKNoconnect(unsigned Begin, unsigned& kmax, unsigned& kmin, vector<unsigned>& FindOrNot, vector<vector<unsigned>>& WaitingList, const vector<vector<unsigned>>& Gx
	, vector<int>& L_Degree, unsigned f, unsigned inse, unsigned anf, unsigned aninse, bool& end)
{
	//find a connected graph begin to Begin in Gx, and find the biggest k-core of the connected graph
	WaitingList[kmax].push_back(Begin);
	for (unsigned i = kmax; i >= kmin; --i)
	{
		while (!WaitingList[i].empty())
		{
			unsigned x = WaitingList[i].back();
			WaitingList[i].pop_back();
			if (FindOrNot[x] == anf || FindOrNot[x] == aninse || end)// || i == kmin
			{
				end = true;
				kmax = i;
				return;
			}
			FindOrNot[x] = f;
			for (auto& nei : Gx[x])
			{
				if (L_Degree[nei] < kmin)
				{
					continue;
				}
				if (FindOrNot[nei] == 0)
				{
					if (L_Degree[nei] >= i)
					{
						WaitingList[i].push_back(nei);
						FindOrNot[nei] = inse;
					}
					else
					{
						WaitingList[L_Degree[nei]].push_back(nei);
						FindOrNot[nei] = inse;
					}
				}
				else
				{
					if (FindOrNot[nei] == f || FindOrNot[nei] == inse)
					{
						continue;
					}
					else if (L_Degree[nei] >= i)
					{
						end = true;
						kmax = i;
						return;
					}
					else if (L_Degree[nei] < i)
					{
						kmin = std::max(int(kmin), L_Degree[nei]);
					}
				}
			}
		}
	}
	end = true;
	kmax = 0;
	return;
}

unsigned ConnectedVarifytest(unsigned kpre, unsigned q, unsigned m, vector<int>& L_Degree, vector<int>& bin, const vector<vector<unsigned>>& Gx, vector<int>& Connect)
{
	//varify whether the nodes q and m connected
	//after varify_kcore(), bin[x]-bin[x-1] if the number of nodes with degree x
	//after varify_kcore(), bin.size()-bin[x] is the number of nodes with degree >= x
	unsigned kmaxq = std::min(L_Degree[q], L_Degree[m]);//the biggest value may be reach of connected k-core contains q and m
	unsigned kmaxm = kmaxq;
	unsigned kmin = kpre + 1;//the smallest value must be reach of connected k-core contains q and m
	//0 means not find, 1 means is find by q, 2 means is find by m, 3 means insert to waiting list by q, 4 means insert to waiting list by m
	vector<unsigned> FindOrNot(L_Degree.size(), 0);
	vector<deque<unsigned>> WaitingListq(kmaxq + 1);//, WaitingListm(kmaxq + 1)
	/*
	for (unsigned i = 0; i != kmaxq; ++i)
	{
		WaitingListq[i].reserve(bin[i + 1] - bin[i]);
		WaitingListm[i].reserve(bin[i + 1] - bin[i]);
	}
	WaitingListq[kmaxq].reserve(L_Degree.size() - bin[kmaxq]);*/
	//WaitingListm[kmaxq].reserve(L_Degree.size() - bin[kmaxq]);
	//bool end = false;
	TheBiggestK(q, m, ref(kmaxq), ref(kmin), ref(FindOrNot), ref(WaitingListq), cref(Gx), ref(L_Degree),
		1, 3, ref(Connect));
	//thread threadq(TheBiggestK, q, ref(kmaxq), ref(kmin), ref(FindOrNot), ref(WaitingListq), cref(Gx), ref(L_Degree),
	//	1, 3, 2, 4, ref(end), ref(Connect));
	//thread threadm(TheBiggestK, m, ref(kmaxm), ref(kmin), ref(FindOrNot), ref(WaitingListm), cref(Gx), ref(L_Degree),
	//	2, 4, 1, 3, ref(end), ref(Connect));
	//threadq.join();
	//threadm.join();
	return kmaxq;
	//return kmaxq = max(kmaxq, kmaxm);
}

unsigned ConnectedVarifyNoconnect(unsigned q, unsigned m, vector<int>& L_Degree, vector<int>& bin, const vector<vector<unsigned>>& Gx)
{
	//varify whether the nodes q and m connected
	//after varify_kcore(), bin[x]-bin[x-1] if the number of nodes with degree x
	//after varify_kcore(), bin.size()-bin[x] is the number of nodes with degree >= x
	unsigned kmaxq = std::min(L_Degree[q], L_Degree[m]);//the biggest value may be reach of connected k-core contains q and m
	unsigned kmaxm = kmaxq;
	unsigned kmin = 2;//the smallest value must be reach of connected k-core contains q and m
	//0 means not find, 1 means is find by q, 2 means is find by m, 3 means insert to waiting list by q, 4 means insert to waiting list by m
	vector<unsigned> FindOrNot(L_Degree.size(), 0);
	vector<deque<unsigned>> WaitingListq(kmaxq + 1);//, WaitingListm(kmaxq + 1)
	//for (unsigned i = 0; i < kmaxq; ++i)
	//{
	//	WaitingListq[i].reserve(bin[i + 1] - bin[i]);
	//	WaitingListm[i].reserve(bin[i + 1] - bin[i]);
	//}
	//WaitingListq[kmaxq].reserve(L_Degree.size() - bin[kmaxq]);
	//WaitingListm[kmaxq].reserve(L_Degree.size() - bin[kmaxq]);
	TheBiggestKsingle(q, m, ref(kmaxq), ref(kmin), ref(FindOrNot), ref(WaitingListq), cref(Gx), ref(L_Degree),
		1, 3);
	//thread threadq(TheBiggestKNoconnect, q, ref(kmaxq), ref(kmin), ref(FindOrNot), ref(WaitingListq), cref(Gx), ref(L_Degree),
	//	1, 3, 2, 4, ref(end));
	//thread threadm(TheBiggestKNoconnect, m, ref(kmaxm), ref(kmin), ref(FindOrNot), ref(WaitingListm), cref(Gx), ref(L_Degree),
	//	2, 4, 1, 3, ref(end));
	//threadq.join();
	//threadm.join();

	return kmaxq;
}

unsigned ConnectedVarifyNoconnecttest(unsigned kpre, unsigned q, unsigned m, vector<int>& L_Degree, vector<int>& bin, const vector<vector<unsigned>>& Gx)
{
	//varify whether the nodes q and m connected
	//after varify_kcore(), bin[x]-bin[x-1] if the number of nodes with degree x
	//after varify_kcore(), bin.size()-bin[x] is the number of nodes with degree >= x
	unsigned kmaxq = std::min(L_Degree[q], L_Degree[m]);//the biggest value may be reach of connected k-core contains q and m
	unsigned kmaxm = kmaxq;
	unsigned kmin = kpre + 1;//the smallest value must be reach of connected k-core contains q and m
	//0 means not find, 1 means is find by q, 2 means is find by m, 3 means insert to waiting list by q, 4 means insert to waiting list by m
	vector<unsigned> FindOrNot(L_Degree.size(), 0);
	vector<vector<unsigned>> WaitingListq(kmaxq + 1), WaitingListm(kmaxq + 1);
	for (unsigned i = 0; i < kmaxq; ++i)
	{
		WaitingListq[i].reserve(bin[i + 1] - bin[i]);
		WaitingListm[i].reserve(bin[i + 1] - bin[i]);
	}
	WaitingListq[kmaxq].reserve(L_Degree.size() - bin[kmaxq]);
	WaitingListm[kmaxq].reserve(L_Degree.size() - bin[kmaxq]);
	bool end = false;
	//TheBiggestK(q, ref(kmaxq), ref(kmin), ref(FindOrNot), ref(WaitingListq), cref(Gx), ref(L_Degree),
	//	1, 3, 2, 4, ref(end), ref(Connect));
	thread threadq(TheBiggestKNoconnect, q, ref(kmaxq), ref(kmin), ref(FindOrNot), ref(WaitingListq), cref(Gx), ref(L_Degree),
		1, 3, 2, 4, ref(end));
	thread threadm(TheBiggestKNoconnect, m, ref(kmaxm), ref(kmin), ref(FindOrNot), ref(WaitingListm), cref(Gx), ref(L_Degree),
		2, 4, 1, 3, ref(end));
	threadq.join();
	threadm.join();

	return kmaxq = max(kmaxq, kmaxm);
}

void varify_kcore(unsigned q, unsigned m, const vector<vector<unsigned>>& Gx, vector<int>& L_Degree, vector<int>& bin, vector<int>& pos
	, vector<int>& vert)
{
	//after varify_kcore(), bin[x]-bin[x-1] if the number of nodes with degree x
	//after varify_kcore(), bin.size()-bin[x] is the number of nodes with degree >= x
	//after varify_kcore(), pos[x] is the position of the first node with degree x
	//after varify_kcore(), vert is the list of nodes in the k-core
	//after varify_kcore(), L_Degree is the degree of each node
	L_Degree.clear();
	pos.clear();
	bin.clear();
	int n = Gx.size();
	int Md = 0;//Md�������ڵ�ȣ����Թ���bin�Ĵ�С��
	//��L_Degree�в���ڵ��ھӸ����������±��Ƕ�Ӧ������ID
	L_Degree.reserve(n);
	int i = 0;
	for (const auto& a : Gx)
	{
		int sizee = a.size();
		L_Degree.push_back(sizee);
		Md = max(Md, sizee);
	}
	bin.resize(Md + 1, 0);
	for (int i = 0; i != n; ++i)
	{
		++bin[L_Degree[i]];
	}
	int start = 0;
	int num = 0;
	for (int d = 0; d != Md + 1; ++d)
	{
		num = bin[d];
		bin[d] = start;
		start += num;
	}
	pos.reserve(n);
	vert.resize(n);
	for (int i = 0; i != n; ++i)
	{
		pos.push_back(bin[L_Degree[i]]++);
		vert[pos[i]] = i;
	}
	for (int d = Md; d != 0; --d)
	{
		bin[d] = bin[d - 1];
	}
	bin[0] = 0;
	for (int i = 0; i != n; ++i)
	{
		int v = vert[i];
		if (v == q || v == m)
		{
			break;
		}
		auto& Neis = Gx[v];
		for (auto& u : Neis)
		{

			if (L_Degree[u] > L_Degree[v])
			{
				int du = L_Degree[u];
				int pu = pos[u];
				int pw = bin[du];
				int w = vert[pw];
				if (u != w)
				{
					pos[u] = pw;
					vert[pu] = w;
					pos[w] = pu;
					vert[pw] = u;
				}
				++bin[du];
				--L_Degree[u];
			}
		}
	}
	//cout << "core number veritf all" << endl;
	/*for(auto a : L_Degree)
	{
		cout << a << " " ;
	}*/
}