#pragma once
#include "OverloadedSearch.h"

using namespace std;
using namespace std::chrono;

bool Rvarify_kcore(int q, int m, int k, const vector<vector<unsigned>>& Gx, vector<int>& L_Degree, vector<int>& bin, vector<int>& pos
	, vector<int>& vert);// varify that the core number of query vertex and missing vertex is greater then k
bool Rconnected_verifySingleThread(int q, int m, int k, const vector<vector<unsigned>>& Gx, vector<int>& L_Degree);


class R_Refr
{
public:
	bool varify_Dqm(int q, int m, int k, MyTree& Rtree_G, const vector<pair<float, float>>& GraphG_Location,
		const vector<vector<unsigned>>& GraphG, float& rend, OverloadedSearch& overloadedSearch);//varify the exict of connected k-core contain both query vertex and missing vertex if r'=d(m,q)/2
	bool Rconnected_verifyMutiThread(int q, int m, int k, const vector<vector<unsigned>>& Gx, vector<int>& L_Degree);
	vector<int>& Get_L_Degree()
	{
		return L_Degree;
	}
private:
	vector<int> L_Degree;
	vector<int> bin;
	vector<int> pos;
	vector<int> vert;


};

bool R_Refr::varify_Dqm(int q, int m, int k, MyTree& Rtree_G, const vector<pair<float, float>>& GraphG_Location,
	const vector<vector<unsigned>>& GraphG, float& rend, OverloadedSearch& overloadedSearch)
{
	vector<vector<unsigned>> subgraph(CandidateGk.size());

	float CircleRadius = hypot((GraphG_Location[q].first - GraphG_Location[m].first),(GraphG_Location[q].second - GraphG_Location[m].second)) / 2.0;
	pair<float,float> CircleCenter = { (GraphG_Location[q].first + GraphG_Location[m].first) / 2.0,  (GraphG_Location[q].second + GraphG_Location[m].second) / 2.0 };
	overloadedSearch.SearchR_Refr(GraphG_Location.size()/5, CircleCenter, CircleRadius, Rtree_G, subgraph, CandidateGk, Gk_OldNew, GraphG);
	auto nq = Gk_OldNew[q];
	auto nm = Gk_OldNew[m];
	if (Rvarify_kcore(nq, nm, k, subgraph, L_Degree, bin, pos, vert))
	{
		rend = CircleRadius;
		return Rconnected_verifySingleThread(nq, nm, k, subgraph, L_Degree);
	}
	return false;
}


bool Rvarify_kcore(int q, int m, int k, const vector<vector<unsigned>>& Gx, vector<int>& L_Degree, vector<int>& bin, vector<int>& pos
	, vector<int>& vert)
{
	L_Degree.clear();
	pos.clear();
	bin.clear();
	int n = Gx.size();
	int Md = 0;//Md�������ڵ�ȣ����Թ���bin�Ĵ�С��
	//��L_Degree�в���ڵ��ھӸ����������±��Ƕ�Ӧ������ID
	L_Degree.reserve(n);
	int i = 0;
	for (const auto& a : Gx)
	{
		int sizee = a.size();
		L_Degree.push_back(sizee);
		Md = max(Md, sizee);
	}
	bin.resize(Md + 1, 0);
	for (int i = 0; i != n; ++i)
	{
		++bin[L_Degree[i]];
	}
	int start = 0;
	int num = 0;
	for (int d = 0; d != Md + 1; ++d)
	{
		num = bin[d];
		bin[d] = start;
		start += num;
	}
	pos.reserve(n);
	vert.resize(n);
	for (int i = 0; i != n; ++i)
	{
		pos.push_back(bin[L_Degree[i]]++);
		vert[pos[i]] = i;
	}
	for (int d = Md; d != 0; --d)
	{
		bin[d] = bin[d - 1];
	}
	bin[0] = 0;
	for (int i = 0; i != n; ++i)
	{
		int v = vert[i];
		if (L_Degree[v] >= k)
		{
			return true;
		}
		if (L_Degree[q] < k || L_Degree[m] < k)
		{
			return false;
		}
		auto& Neis = Gx[v];
		for (auto& u : Neis)
		{

			if (L_Degree[u] > L_Degree[v])
			{
				int du = L_Degree[u];
				int pu = pos[u];
				int pw = bin[du];
				int w = vert[pw];
				if (u != w)
				{
					pos[u] = pw;
					vert[pu] = w;
					pos[w] = pu;
					vert[pw] = u;
				}
				++bin[du];
				--L_Degree[u];
			}
		}
	}
	//cout << "core number veritf all" << endl;
	return false;
	/*for(auto a : L_Degree)
	{
		cout << a << " " ;
	}*/
}


void Delay(int time)
{
	clock_t  now = clock();
	while (clock() - now < time);
}

void DFSMutiThread(const int& v, int k, bool& end, vector<bool>& FindOrNot1, vector<bool>& FindOrNot2, const vector<vector<unsigned>>& Gx, vector<int>& L_Degree)
{
	//Delay(1000);
	if (end)
	{
		return;
	}
	for (const auto& a : Gx[v])
	{
		if (!FindOrNot1[a] && L_Degree[a] >= k && !end)
		{
			FindOrNot1[a] = true;
			if (FindOrNot1[a] == FindOrNot2[a])
			{
				end = true;
				return;
			}
			DFSMutiThread(cref(a), k, ref(end), ref(FindOrNot1), ref(FindOrNot2), cref(Gx), ref(L_Degree));
		}
	}
}

bool R_Refr::Rconnected_verifyMutiThread(int q, int m, int k, const vector<vector<unsigned>>& Gx, vector<int>& L_Degree)
{
	bool end = false;
	vector<bool> FindOrNotq(Gx.size(), false);
	vector<bool> FindOrNotm(Gx.size(), false);
	FindOrNotq[q] = true;
	FindOrNotm[m] = true;
	thread threadq(DFSMutiThread, cref(q), k, ref(end), ref(FindOrNotq), ref(FindOrNotm), cref(Gx), ref(L_Degree));
	thread threadm(DFSMutiThread, cref(m), k, ref(end), ref(FindOrNotm), ref(FindOrNotq), cref(Gx), ref(L_Degree));
	//threadq.join();
	//DFS(q, k, end, FindOrNotq, FindOrNotm, Gx, L_Degree);
	threadq.join();
	threadm.join();
	return end;
}


bool ConnectedSingleThread(int q, int m, int k, vector<bool>& FindOrNot, const vector<vector<unsigned>>& Gx, vector<int>& L_Degree)
{
	deque<unsigned> Q;
	Q.push_back(q);
	Q.push_back(m);
	FindOrNot[q] = true;
	FindOrNot[m] = true;
	//Delay(1000);
	unsigned&& v = 0;
	while (!Q.empty())
	{
		v = Q.front();
		Q.pop_front();
		for (const auto& a : Gx[v])
		{
			if (!FindOrNot[a] && L_Degree[a] >= k)
			{
				FindOrNot[a] = true;
				Q.push_back(a);
			}
			else if(FindOrNot[a] && L_Degree[a] >= k)
			{
				return true;
			}
		}
	}
	return false;
}


bool Rconnected_verifySingleThread(int q, int m, int k, const vector<vector<unsigned>>& Gx, vector<int>& L_Degree)
{
	vector<bool> FindOrNot(Gx.size(), false);
	return ConnectedSingleThread(q, m, k, FindOrNot, Gx, L_Degree);
}