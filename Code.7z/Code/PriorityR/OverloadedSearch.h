#ifndef OverloadedSearch_HH
#define OverloadedSearch_HH



#pragma once
#include "ReadData.h"
#include <functional>

class OverloadedSearch
{

	

public:
	OverloadedSearch() {}
	~OverloadedSearch() {}

	//R_Expension
	bool MySearchCallbackExpension(ValueType v)
	{
		float && distanceold = powl((v.second.first - CircleCenter.first), 2.0) + powl((v.second.second - CircleCenter.second), 2.0);
		float && distancenew = powl((v.second.first - CircleCenterNew.first), 2.0) + powl((v.second.second - CircleCenterNew.second), 2.0);
		if (distancenew <= CircleRadiusNew2 + 0.0001 && CircleRadius2 + 0.0001 < distanceold && (*degrees)[v.first] >= kprime)
		{
			(*CandidateGk).push_back(v.first);
			(*OldToNew)[v.first] = counts++;
			Find[v.first] = false;
		}
		//cout << "Hit data rect " << id << "\n";
		return true; // keep going
	}
	std::function<bool(const ValueType&)> callbackR_Expension = std::bind(&OverloadedSearch::MySearchCallbackExpension, this, std::placeholders::_1);
	unsigned SearchRExpension(pair<float, float> Center, float Radius, pair<float, float> NewCenter, float NewRadius, MyTree& Tree, vector<vector<unsigned>>& ExNewGraph,
		vector<unsigned>& ExCandidateGk, std::vector<unsigned>& ExOldToNew, const vector<vector<unsigned>>& GraphG, vector<int>& ExL_Degree, pair<int, int>& begintoend)
	{
		begintoend.first = counts;
		CandidateGk = &ExCandidateGk;

		CircleCenter = Center;
		CircleRadius2 = Radius * Radius + 0.0001;
		CircleCenterNew = NewCenter;
		CircleRadiusNew2 = NewRadius * NewRadius + 0.0001;
		float min[] = { CircleCenterNew.first - NewRadius, CircleCenterNew.second - NewRadius };
		float max[] = { CircleCenterNew.first + NewRadius, CircleCenterNew.second + NewRadius };
		Tree.Search(min, max, callbackR_Expension);
		begintoend.second = counts;


		ExNewGraph.reserve((*CandidateGk).size());
		for (unsigned j = begintoend.first; j != counts; ++j)
		{
			ExNewGraph.push_back({});
			for(auto & nei : GraphG[(*CandidateGk)[j]])
			{
				if (!Find[nei])
				{
					if(Gk_OldNew[nei] < j)
					{
						ExNewGraph[j].push_back(Gk_OldNew[nei]);
						ExNewGraph[Gk_OldNew[nei]].push_back(j);
					}
				}
			}
		}

		return (*CandidateGk).size();

	}

	// belong to R_Expension, search a set of vertices in a circle and create a newgraph
	bool MySearchCallbackR_ExpensionUp(ValueType v)
	{
		float distance = powl((v.second.first - CircleCenter.first), 2.0) + powl((v.second.second - CircleCenter.second), 2.0);
		if (distance <= CircleRadius2 + 0.0001 && (*degrees)[v.first] >= kprime)
		{
			(*CandidateGk).push_back(v.first);
			(*OldToNew)[v.first] = counts++;
			Find[v.first] = false;
		}
		//cout << "Hit data rect " << id << "\n";
		return true; // keep going
	}
	std::function<bool(const ValueType&)> callbackR_ExpensionUp = std::bind(&OverloadedSearch::MySearchCallbackR_ExpensionUp, this, std::placeholders::_1);
	unsigned SearchR_ExpensionUp(unsigned size, int k, pair<float, float> Center, float Radius, MyTree& Tree, vector<vector<unsigned>>& ExNewGraph,
		vector<unsigned>& ExCandidateGk, std::vector<unsigned>& ExOldToNew, const vector<vector<unsigned>>& GraphG, vector<int>& ExL_Degree)
	{
		ExCandidateGk.clear();
		ExNewGraph.clear();
		counts = 0;
		ExCandidateGk.reserve(size);

		kprime = k;
		OldToNew = &ExOldToNew;
		CandidateGk = &ExCandidateGk;
		NewGraph = &ExNewGraph;
		degrees = &ExL_Degree;

		CircleCenter = Center;
		CircleRadius2 = Radius * Radius;
		float min[] = { CircleCenter.first - Radius, CircleCenter.second - Radius };
		float max[] = { CircleCenter.first + Radius, CircleCenter.second + Radius };
		Tree.Search(min, max, callbackR_ExpensionUp);


		Great_Graph_ByPoint(*CandidateGk, *NewGraph, GraphG);
		return CandidateGk->size();
	}


	// belong to R_Refr, search a set of vertices in a circle
	bool MySearchCallbackR_Refr(ValueType v)
	{
		float distance = powl((v.second.first - CircleCenter.first), 2.0) + powl((v.second.second - CircleCenter.second), 2.0);
		if (distance <= CircleRadius2 + 0.0001)
		{
			(*CandidateGk).push_back(v.first);
			(*OldToNew)[v.first] = counts++;
			Find[v.first] = false;
		}
		//cout << "Hit data rect " << id << "\n";
		return true; // keep going
	}
	std::function<bool(const ValueType&)> callbackR_Refr = std::bind(&OverloadedSearch::MySearchCallbackR_Refr, this, std::placeholders::_1);
	unsigned SearchR_Refr(unsigned size, pair<float, float> Center, float Radius, MyTree& Tree, vector<vector<unsigned>>& ExNewGraph,
		vector<unsigned>& ExCandidateGk, std::vector<unsigned>& ExOldToNew, const vector<vector<unsigned>>& GraphG)
	{

		ExCandidateGk.clear();
		ExNewGraph.clear();
		counts = 0;
		ExCandidateGk.reserve(size);

		OldToNew = &ExOldToNew;
		CandidateGk = &ExCandidateGk;
		NewGraph = &ExNewGraph;

		CircleCenter = Center;
		CircleRadius2 = Radius * Radius;
		float min[] = { CircleCenter.first - Radius, CircleCenter.second - Radius };
		float max[] = { CircleCenter.first + Radius, CircleCenter.second + Radius };
		Tree.Search(min, max, callbackR_Refr);


		Great_Graph_ByPoint(*CandidateGk, *NewGraph, GraphG);
		for (auto& a : *CandidateGk)
		{
			Find[a] = true;
		}
		return CandidateGk->size();
	}

	// belong to R_RefinedRPlus NoIndex, search a set of vertices in a circle by degree
	bool MySearchCallbackR_RRefine(ValueType v)
	{
		float distance = powl((v.second.first - CircleCenter.first), 2.0) + powl((v.second.second - CircleCenter.second), 2.0);
		if (distance <= CircleRadius2 + 0.0001 && (*degrees)[v.first] >= kprime)
		{
			(*CandidateGk).push_back(v.first);
			(*OldToNew)[v.first] = counts++;
			Find[v.first] = false;
		}
		//cout << "Hit data rect " << id << "\n";
		return true; // keep going
	}
	std::function<bool(const ValueType&)> callbackR_RRefine = std::bind(&OverloadedSearch::MySearchCallbackR_RRefine, this, std::placeholders::_1);
	unsigned SearchR_RRefine(pair<float, float> Center, float Radius, MyTree& Tree, vector<vector<unsigned>>& ExNewGraph,
		vector<unsigned>& ExCandidateGk, std::vector<unsigned>& ExOldToNew, const vector<vector<unsigned>>& GraphG, vector<int>& ExL_Degree)
	{
		ExCandidateGk.clear();
		ExNewGraph.clear();
		counts = 0;

		degrees = &ExL_Degree;
		OldToNew = &ExOldToNew;
		CandidateGk = &ExCandidateGk;
		NewGraph = &ExNewGraph;

		CircleCenter = Center;
		CircleRadius2 = Radius * Radius;
		float min[] = { CircleCenter.first - Radius, CircleCenter.second - Radius };
		float max[] = { CircleCenter.first + Radius, CircleCenter.second + Radius };
		Tree.Search(min, max, callbackR_Refr);


		Great_Graph_ByPoint(*CandidateGk, *NewGraph, GraphG);
		for (auto& a : *CandidateGk)
		{
			Find[a] = true;
		}
		return CandidateGk->size();
	}


	// belong to R_RefinedRPlus WithIndex, search a set of vertices in a circle by degree
	bool MySearchCallbackR_RRefineWithIndex(ValueType v)
	{
		float distance = powl((v.second.first - CircleCenter.first), 2.0) + powl((v.second.second - CircleCenter.second), 2.0);
		if (distance <= CircleRadius2 + 0.0001 && (*degrees)[v.first] >= kprime)
		{
			(*CandidateGk).push_back(v.first);
			(*OldToNew)[v.first] = counts++;
			Find[v.first] = false;
			return true;
		}
		else
		{
			return false;
		}
		//cout << "Hit data rect " << id << "\n";
		
	}
	std::function<bool(const ValueType&)> callbackR_RRefineWithIndex = std::bind(&OverloadedSearch::MySearchCallbackR_RRefineWithIndex, this, std::placeholders::_1);
	unsigned SearchR_RRefineWithIndex(unsigned q, unsigned m, pair<float, float> Center, float Radius, MyTree& Tree, vector<vector<unsigned>>& ExNewGraph,
		vector<unsigned>& ExCandidateGk, std::vector<unsigned>& ExOldToNew, const vector<vector<unsigned>>& GraphG, vector<int>& ExL_Degree,
		const vector<vector<int> >& AfterProLeverCoreness)
	{
		ExCandidateGk.clear();
		ExNewGraph.clear();
		counts = 0;

		degrees = &ExL_Degree;
		OldToNew = &ExOldToNew;
		CandidateGk = &ExCandidateGk;
		NewGraph = &ExNewGraph;

		CircleCenter = Center;
		CircleRadius2 = Radius * Radius;
		float min[] = { CircleCenter.first - Radius, CircleCenter.second - Radius };
		float max[] = { CircleCenter.first + Radius, CircleCenter.second + Radius };
		unsigned lever = Tree.SearchWithLever(min, max, callbackR_RRefineWithIndex);

		if (AfterProLeverCoreness[lever][q] < kprime || AfterProLeverCoreness[lever][m] < kprime)
		{
			for (auto& a : *CandidateGk)
			{
				Find[a] = true;
			}
			++IndexUsednumber;
			return 0;
		}

		Great_Graph_ByPoint(*CandidateGk, *NewGraph, GraphG);
		for (auto& a : *CandidateGk)
		{
			Find[a] = true;
		}
		return CandidateGk->size();
	}

	//===========================================Edge search by degree, Create by CircleCenter and radius===========================================
	//===========================================AccruateK Redined k===========================================
	/**/
	bool MySearchCallbackbydegreeIndex(ValueType v)
	{
		float distanceol = powl((v.second.first - CircleCenter.first), 2.0) + powl((v.second.second - CircleCenter.second), 2.0);
		if (distanceol <= CircleRadius2 && (*degrees)[v.first] >= kprime)
		{
			(*CandidateGk).push_back(v.first);
			(*OldToNew)[v.first] = counts++;
			Find[v.first] = false;
			return true;
		}
		else
		{
			return false;
		}
		//cout << "Hit data rect " << id << "\n";
		//return true; // keep going
	}
	std::function<bool(const ValueType&)> callbacke = std::bind(&OverloadedSearch::MySearchCallbackbydegreeIndex, this, std::placeholders::_1);
	//Using center/radius/kprime/degree create a NewGraph
	unsigned SearchEdgeByDegreeIndex(unsigned q, unsigned m, vector<int>& Exdegrees, unsigned Exkprime, pair<float, float> Center,
		float Radius, MyTree& Tree, vector<vector<unsigned>>& ExNewGraph, vector<unsigned>& ExCandidateGk, vector<vector<unsigned>>& GraphG_AfterPreProcess
		, vector<vector<int> >& AfterProLeverCoreness)
	{
		ExCandidateGk.clear();
		ExNewGraph.clear();
		counts = 0;

		CandidateGk = &ExCandidateGk;
		NewGraph = &ExNewGraph;
		degrees = &Exdegrees;
		kprime = Exkprime;
		CircleCenter = Center;
		CircleRadius = Radius;
		CircleRadius2 = CircleRadius * CircleRadius + 0.00001;
		float min[] = { CircleCenter.first - CircleRadius, CircleCenter.second - CircleRadius };
		float max[] = { CircleCenter.first + CircleRadius, CircleCenter.second + CircleRadius };
		unsigned lever = Tree.SearchWithLever(min, max, callbacke);
		if (AfterProLeverCoreness[lever][q] <= Exkprime || AfterProLeverCoreness[lever][m] <= Exkprime)//Actually Using
		{
			++IndexUsednumber;
			for (auto& a : *CandidateGk)
			{
				Find[a] = true;
			}
			return 0;
		}
		Great_Graph_ByPoint(*CandidateGk, *NewGraph, GraphG_AfterPreProcess);
		for (auto& a : *CandidateGk)
		{
			Find[a] = true;
		}
		return CandidateGk->size();
	}


	//===========================================Edge search by degree, Create by CircleCenter and radius===========================================
//===========================================AccruateK Redined k  With Index===========================================

	unsigned SearchEdgeByDegree(vector<int>& Exdegrees, unsigned Exkprime, pair<float, float> Center,
		float Radius, MyTree& Tree, vector<vector<unsigned>>& ExNewGraph, vector<unsigned>& ExCandidateGk, vector<vector<unsigned>>& GraphG_AfterPreProcess)
	{
		ExCandidateGk.clear();
		ExNewGraph.clear();
		counts = 0;

		OldToNew = &Gk_OldNew;
		CandidateGk = &ExCandidateGk;
		NewGraph = &ExNewGraph;
		degrees = &Exdegrees;
		kprime = Exkprime;
		CircleCenter = Center;
		CircleRadius = Radius;
		CircleRadius2 = CircleRadius * CircleRadius + 0.00001;
		float min[] = { CircleCenter.first - CircleRadius, CircleCenter.second - CircleRadius };
		float max[] = { CircleCenter.first + CircleRadius, CircleCenter.second + CircleRadius };
		Tree.SearchWithLever(min, max, callbacke);


		Great_Graph_ByPoint(*CandidateGk, *NewGraph, GraphG_AfterPreProcess);
		for (auto& a : *CandidateGk)
		{
			Find[a] = true;
		}
		return CandidateGk->size();
	}
	//===========================================Edge search no degree, Create by CircleCenter and radius===========================================
	//===========================================AccruateK Redined k===========================================
	bool MySearchCallbackPrePru(ValueType v)
	{
		float distanceol = powl((v.second.first - CircleCenter.first), 2.0) + powl((v.second.second - CircleCenter.second), 2.0);
		if (distanceol <= CircleRadius2)
		{
			(*CandidateGk).push_back(v.first);
			(*OldToNew)[v.first] = counts++;
			Find[v.first] = false;
		}
		//cout << "Hit data rect " << id << "\n";
		return true; // keep going
	}
	std::function<bool(const ValueType&)> callbackEnodrgree = std::bind(&OverloadedSearch::MySearchCallbackPrePru, this, std::placeholders::_1);
	unsigned SearchEdgeNoDegree(pair<float, float> Center, float Radius, MyTree& Tree, vector<vector<unsigned>>& ExNewGraph, 
		vector<unsigned>& ExCandidateGk, std::vector<unsigned>& ExOldToNew, vector<vector<unsigned>>& GraphG_AfterPreProcess)
	{
		ExCandidateGk.clear();
		ExNewGraph.clear();
		counts = 0;

		OldToNew = &ExOldToNew;
		CandidateGk = &ExCandidateGk;
		NewGraph = &ExNewGraph;
		CircleCenter = Center;
		CircleRadius2 = Radius * Radius + 0.00001;
		float min[] = { CircleCenter.first - Radius, CircleCenter.second - Radius };
		float max[] = { CircleCenter.first + Radius, CircleCenter.second + Radius };
		Tree.Search(min, max, callbackEnodrgree);

		Great_Graph_ByPoint(*CandidateGk, *NewGraph, GraphG_AfterPreProcess);
		for (auto& a : *CandidateGk)
		{
			Find[a] = true;
		}

		return (*CandidateGk).size();
	}


	bool MySearchCallbackPrePruIndex(ValueType v)
	{
		float distanceol = powl((v.second.first - CircleCenter.first), 2.0) + powl((v.second.second - CircleCenter.second), 2.0);
		if (distanceol <= CircleRadius2)
		{
			(*CandidateGk).push_back(v.first);
			(*OldToNew)[v.first] = counts++;
			Find[v.first] = false;
			return true; // keep going
		}
		else
		{
			return false;
		}
		//cout << "Hit data rect " << id << "\n";
		
	}
	std::function<bool(const ValueType&)> callbackEnodrgreeindex = std::bind(&OverloadedSearch::MySearchCallbackPrePruIndex, this, std::placeholders::_1);
	unsigned SearchEdgeNoDegreeIndex(unsigned q, unsigned m, unsigned k, pair<float, float> Center, float Radius, MyTree& Tree, vector<vector<unsigned>>& ExNewGraph,
		vector<unsigned>& ExCandidateGk, std::vector<unsigned>& ExOldToNew, vector<vector<unsigned>>& GraphG_AfterPreProcess, const vector<vector<int> >& AfterProLeverCoreness)
	{
		ExCandidateGk.clear();
		ExNewGraph.clear();
		counts = 0;

		OldToNew = &ExOldToNew;
		CandidateGk = &ExCandidateGk;
		NewGraph = &ExNewGraph;
		CircleCenter = Center;
		CircleRadius2 = Radius * Radius + 0.00001;
		float min[] = { CircleCenter.first - Radius, CircleCenter.second - Radius };
		float max[] = { CircleCenter.first + Radius, CircleCenter.second + Radius };
		unsigned lever = Tree.SearchWithLever(min, max, callbackEnodrgreeindex);
		if (AfterProLeverCoreness[lever][q] <= k || AfterProLeverCoreness[lever][m] <= k)
		{
			for (auto& a : *CandidateGk)
			{
				Find[a] = true;
			}
			++IndexUsednumber;
			return 0;
		}

		Great_Graph_ByPoint(*CandidateGk, *NewGraph, GraphG_AfterPreProcess);
		for (auto& a : *CandidateGk)
		{
			Find[a] = true;
		}

		return (*CandidateGk).size();
	}
	//===========================================Redined k PreProcessing===========================================
	bool MySearchCallbackRelationship(ValueType v)
	{
		float&& distanceolq = powl((v.second.first - CircleCenterq.first), 2.0) + powl((v.second.second - CircleCenterq.second), 2.0);
		float&& distancenem = powl((v.second.first - CircleCenterm.first), 2.0) + powl((v.second.second - CircleCenterm.second), 2.0);
		if (distanceolq <= CircleRadius2 && distancenem <= CircleRadius2)
		{
			(*CandidateGk).push_back(v.first);
			(*CandidateGk_Location).push_back({ v.second.first , v.second.second });
			(*OldToNew)[v.first] = counts++;
			Find[v.first] = false;
		}
		//cout << "Hit data rect " << id << "\n";
		return true; // keep going
	}
	std::function<bool(const ValueType&)> callbackv = std::bind(&OverloadedSearch::MySearchCallbackRelationship, this, std::placeholders::_1);
	//Using center/radius/kprime/degree create a NewGraph
	unsigned SearchVertexNodegree(unsigned size, pair<float, float> Centerq, pair<float, float> Centerm,
		float Radius, MyTree& Tree, vector<unsigned>& ExCandidateGk, vector<pair<float, float>>& ExCandidateGk_Location, std::vector<unsigned>& ExOldToNew)
	{
		ExCandidateGk_Location.reserve(size);
		ExCandidateGk.clear();
		CandidateGk = &ExCandidateGk;
		CandidateGk_Location = &ExCandidateGk_Location;
		OldToNew = &ExOldToNew;

		counts = 0;
		CircleCenterq = Centerq;
		CircleCenterm = Centerm;
		CircleRadius = Radius;
		CircleRadius2 = 4 * CircleRadius * CircleRadius + 0.00001;
		float min[] = { std::max(Centerq.first, Centerm.first) - 2 * Radius,
			std::max(Centerq.second, Centerm.second) - 2 * Radius };
		float max[] = { std::min(Centerq.first, Centerm.first) + 2 * Radius,
			std::min(Centerq.second, Centerm.second) + 2 * Radius };
		Tree.Search(min, max, callbackv);
		return counts;
	}
	

	//ROTC USED====================================================================================
	// belong to R_RefinedRPlus NoIndex, search a set of vertices in a circle by degree
	bool MySearchCallbackROTCfaraway(ValueType v)
	{
		float distance = powl((v.second.first - CircleCenter.first), 2.0) + powl((v.second.second - CircleCenter.second), 2.0);
		if (distance <= CircleRadius2 + 0.00001 && (*degrees)[v.first] >= kprime)
		{
			(*CandidateGk).push_back(v.first);
			Gk_OldNew[v.first] = counts++;
			Find[v.first] = false;
		}
		//cout << "Hit data rect " << id << "\n";
		return true; // keep going
	}
	std::function<bool(const ValueType&)> callbackROTCfaraway = std::bind(&OverloadedSearch::MySearchCallbackROTCfaraway, this, std::placeholders::_1);
	unsigned SearchROTCfaraway(vector<int>& Exdegrees, unsigned Exkprime, pair<float, float> Center,
		float Radius, MyTree & Tree, vector<vector<unsigned>>&ExNewGraph, vector<unsigned>& ExCandidateGk, vector<vector<unsigned>>&GraphG)
	{
		ExCandidateGk.clear();
		ExNewGraph.clear();
		counts = 0;

		degrees = &Exdegrees;
		CandidateGk = &ExCandidateGk;
		NewGraph = &ExNewGraph;

		kprime = Exkprime;
		CircleCenter = Center;
		CircleRadius2 = Radius * Radius;
		float min[] = { CircleCenter.first - Radius, CircleCenter.second - Radius };
		float max[] = { CircleCenter.first + Radius, CircleCenter.second + Radius };
		Tree.Search(min, max, callbackROTCfaraway);


		Great_Graph_ByPoint(*CandidateGk, *NewGraph, GraphG);
		for (auto& a : *CandidateGk)
		{
			Find[a] = true;
		}
		return CandidateGk->size();
	}

	//=====================================================Pole varify using========================================================================
	bool MySearchCallbackPolevarify(ValueType v)
	{
		float distanceol = powl((v.second.first - CircleCenter.first), 2.0) + powl((v.second.second - CircleCenter.second), 2.0);
		if (distanceol <= CircleRadius2 && (*VGk)[v.first])
		{
			(*CandidateGk).push_back(v.first);
			Gk_OldNew[v.first] = counts++;
			Find[v.first] = false;
			if ((*Result)[v.first])
			{
				newnumber++;
			}
		}

		return true;
		//cout << "Hit data rect " << id << "\n";
		//return true; // keep going
	}
	std::function<bool(const ValueType&)> Polevarify = std::bind(&OverloadedSearch::MySearchCallbackPolevarify, this, std::placeholders::_1);
	unsigned SearchPoleVarify(pair<float, float> Center, float Radius, MyTree& Tree, const vector<bool>& ExVGk, const vector<bool>& ExResults, vector<vector<unsigned>>& ExNewGraph, 
		vector<unsigned>& ExCandidateGk, const vector<vector<unsigned>>& GraphG)
	{
		ExCandidateGk.clear();
		ExNewGraph.clear();
		counts = 0;

		VGk = &ExVGk;
		Result = &ExResults;

		CandidateGk = &ExCandidateGk;
		NewGraph = &ExNewGraph;
		CircleCenter = Center;
		CircleRadius = Radius;
		CircleRadius2 = CircleRadius * CircleRadius + 0.00001;
		float min[] = { CircleCenter.first - CircleRadius, CircleCenter.second - CircleRadius };
		float max[] = { CircleCenter.first + CircleRadius, CircleCenter.second + CircleRadius };

		newnumber = 0;
		Tree.Search(min, max, Polevarify);

		if(newnumber != 0)
		{
			Great_Graph_ByPoint(*CandidateGk, *NewGraph, GraphG);
			for (auto& a : *CandidateGk)
			{
				Find[a] = true;
			}
		}
		else
		{
			for (auto& a : *CandidateGk)
			{
				Find[a] = true;
			}
			return 0;
		}
		return 0;
	}

private:
	vector<vector<unsigned>>* NewGraph;
	vector<int>* degrees;
	unsigned kprime;
	pair<float, float> CircleCenter;
	float CircleRadius;
	float CircleRadius2;
	vector<bool> const* VGk;
	vector<bool> const* Result;
	unsigned newnumber{ 0 };

	unsigned counts;
	vector<unsigned>* CandidateGk;
	vector<pair<float, float>>* CandidateGk_Location;
	std::vector<unsigned>* OldToNew;
	pair<float, float> CircleCenterq;
	pair<float, float> CircleCenterm;


	float CircleRadiusNew;
	float CircleRadiusNew2;
	pair<float, float> CircleCenterNew;
};



#endif // !OverloadedSearch_HH