#pragma once
#include <iostream>
#include "RTree.h"
#include <fstream>
#include <string>
#include <sstream>
#include <unordered_set>
#include <unordered_map>
#include <thread>
#include <ctime>
using namespace std;
using namespace std::chrono;

inline float&& distance(const std::pair<float, float>& a, const std::pair<float, float>& b);

typedef std::pair<int, std::pair<float, float>> ValueType;
typedef RTree<ValueType, float, 2> MyTree;

unsigned IndexUsednumber = 0;


unsigned newnumber = 0;
std::vector<unsigned> CandidateGk{};
std::vector<bool> Find(FILELENGTH, true);
std::vector<unsigned> Gk_OldNew(FILELENGTH, 0);
bool MySearchCallback(ValueType v)
{
	CandidateGk.push_back(v.first);
	Find[v.first] = false;
	Gk_OldNew[v.first] = newnumber++;
	//cout << "Hit data rect " << id << "\n";
	return true; // keep going
}

struct vertex
{
	vertex(unsigned id, float la, float lo)
	{
		this->id = id;
		location.first = la;
		location.second = lo;
		neighbors = {};
	}
	unsigned id;
	pair<float, float> location;
	std::unordered_set<unsigned> neighbors;
};


void Great_Graph_ByPoint(vector<unsigned>& Gk_NewOld, vector<vector<unsigned>>& subgraph, const vector<vector<unsigned>>& GraphG)
{
	subgraph.reserve(Gk_NewOld.size());
	unsigned i = 0;
	for (auto& iteNO : Gk_NewOld)
	{
		subgraph.push_back({});
		subgraph[i].reserve(GraphG[iteNO].size());
		for (auto& iteG : GraphG[iteNO])
		{
			if (!Find[iteG])
			{
				subgraph[i].push_back(Gk_OldNew[iteG]);
			}
		}
		++i;
	}
}




class ReadData
{
public:

	void ReadDataset(string Filename, unsigned Length);
	inline MyTree& GetRtree_G()
	{
		return Rtree_G;
	}
	inline vector<vertex>& GetGraphG()
	{
		return GraphG;
	}
	inline vector<std::vector<unsigned>>& GetarrayGraphG()
	{
		return arrayGraphG;
	}
	inline vector<pair<float, float>>& GetGraphG_Location()
	{
		return GraphG_Location;
	}
	inline vector<int>& GetL_Degree()
	{
		return L_Degree;
	}
private:

	MyTree Rtree_G;//Rtree created by GraphG

	vector<vertex> GraphG; //initial Graph of datasets
	vector<std::vector<unsigned>> arrayGraphG; //initial Graph of datasets
	vector<pair<float, float>> GraphG_Location; //location of vertices

	vector<int> L_Degree;

};

void ReadData::ReadDataset(string Filename, unsigned Length)
{
	ifstream infile;
	infile.open(Filename, ios::in);
	if (!infile.is_open())
	{
		std::cout << Filename << " open fail" << endl;
		return;
	}
	GraphG.reserve(Length);
	GraphG_Location.resize(Length);
	arrayGraphG.resize(Length);
	for (unsigned j = 0; j != Length; ++j)
	{
		vertex v(j, 0, 0);
		GraphG.push_back(v);
	}
	string infileString;
	int id;
	float lati;
	float longi;
	int friends;
	while (getline(infile, infileString))
	{
		stringstream aline(infileString);
		aline >> id;
		aline >> lati;
		aline >> longi;
		float amin[] = { lati, longi };
		float amax[] = { lati, longi };
		Rtree_G.Insert(amin, amax, { id, {lati, longi} });
		GraphG[id].location.first = lati;
		GraphG[id].location.second = longi;
		GraphG_Location[id] = { lati, longi };
		while (aline >> friends)
		{
			//GraphG[id].neighbors.insert(friends);
			arrayGraphG[id].push_back(friends);
			
		}
	}
	// Sorting using the fastest standard library sorting algorithm arrayGraphG[] in acdenting order
	for (auto& a : arrayGraphG)
	{
		std::sort(std::execution::par, a.begin(), a.end());
	}

	vector<int> bin;
	vector<int> pos;
	vector<int> vert;
	O_N_Creat_Corenumber(arrayGraphG, L_Degree, bin, pos, vert);

}

//calculate distance of a and b
inline float&& distance(const std::pair<float, float>& a, const std::pair<float, float>& b)
{
	float&& x = a.first - b.first;
	float&& y = a.second - b.second;
	return std::move(sqrt(x * x + y * y));
}

