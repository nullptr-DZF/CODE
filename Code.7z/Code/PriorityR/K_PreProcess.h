#pragma once
#include "OverloadedSearch.h"


//create a relationship of newpoint to oldpoint Using vertices Rtree
class K_PreProcess
{
public:
	K_PreProcess()
	{
	}
	~K_PreProcess()
	{
	}

	inline vector<vector<unsigned>>& GetGraphG_AfterPreProcess1() { return GraphG_AfterPreProcess; }
	inline vector<pair<float, float>>& GetGraphG_Location_AfterPreProcess1() { return GraphG_Location_AfterPreProcess; }
	inline pair<unsigned, unsigned> Getnm() { return { nq,nm }; }
	inline MyTree& GetAPTree() { return RTree_AfterPreProcess; }

	//Pre-processing according to radius constraints. Get a new graph, a new vertices Rtree and a new edges Rtree.
	void Preprocess(unsigned q, unsigned m, unsigned k, float r, vector<pair<float, float>>& GraphG_Location,
		MyTree& Rtree_G, vector<std::vector<unsigned>>& arrayGraphG, OverloadedSearch& overloadedSearch);
private:
	vector<vector<unsigned>> GraphG_AfterPreProcess;
	vector<pair<float, float>> GraphG_Location_AfterPreProcess;
	MyTree RTree_AfterPreProcess;//REdgetree created by GraphG_AfterPreProcess1


	//the query vertex q and missing vertex m in GraphG_AfterPreProcess after pre-processing
	unsigned nq;
	unsigned nm;
};

void K_PreProcess::Preprocess(unsigned q, unsigned m, unsigned k, float r, vector<pair<float, float>>& GraphG_Location,
	MyTree& Rtree_G, vector<std::vector<unsigned>>& arrayGraphG, OverloadedSearch& overloadedSearch)
{
	overloadedSearch.SearchVertexNodegree(GraphG_Location.size() / 5, GraphG_Location[q], GraphG_Location[m], r, Rtree_G, CandidateGk,
		GraphG_Location_AfterPreProcess, Gk_OldNew);
	Great_Graph_ByPoint(CandidateGk, GraphG_AfterPreProcess, arrayGraphG);
	for (auto& a : CandidateGk)
	{
		Find[a] = true;
	}
	nq = Gk_OldNew[q];
	nm = Gk_OldNew[m];
	for (int i = 0; i != GraphG_AfterPreProcess.size(); ++i)
	{
		float lati = GraphG_Location_AfterPreProcess[i].first;
		float longi = GraphG_Location_AfterPreProcess[i].second;
		float amin[] = { lati, longi };
		float amax[] = { lati, longi };
		RTree_AfterPreProcess.Insert(amin, amax, { i, {lati, longi} });
	}

}