#pragma once
#include "R_Expension.h"

using namespace std;
#define PIs 1.57079632679489661923
bool largest_angle(pair<float, float> p1, pair<float, float> p2, pair<float, float> p3);
inline pair<float, float> calculateCenter(const float& x1, const float& y1, const float& x2, const float& y2, const float& x3, const float& y3, float& radius);
inline pair<float, float> calculateCenter(float x1, float y1, float x2, float y2);
void ConnectedGraphGet(unsigned k, unsigned q, vector<int>& L_Degree, const vector<vector<unsigned>>& Gx, vector<unsigned>& Connect);
void ConnectedGraphNonCandidateGk(unsigned k, unsigned q, vector<int>& L_Degree, const vector<vector<unsigned>>& Gx, vector<unsigned>& Connect);


class R_RefineRPlus
{
public:
    float BestRefinationRWithIndex(int k, int nq, int nm, vector<vector<unsigned>>& SubGraph, vector<int>& ExL_Degree,
        const vector<pair<float, float>>& NewGraphG_Location, MyTree& NewRtree_G, priority_queue<DistanceAndVertex>& NecessaryVertices
        , vector<DistanceAndVertex>& AllVertices, OverloadedSearch& overloadedSearch, vector<vector<int> >& AfterProLeverCoreness);//newtree
    float BestRefinationR(int k, int nq, int nm, vector<vector<unsigned>>& SubGraph, vector<int>& ExL_Degree,
        const vector<pair<float, float>>& NewGraphG_Location, MyTree& NewRtree_G, priority_queue<DistanceAndVertex>& NecessaryVertices
        , vector<DistanceAndVertex>& AllVertices, OverloadedSearch& overloadedSearch);//newtree

private:
    vector<int> L_Degree;
    vector<int> bin;
    vector<int> pos;
    vector<int> vert;
};

float R_RefineRPlus::BestRefinationR(int k, int nq, int nm, vector<vector<unsigned>>& SubGraph, vector<int>& ExL_Degree,
    const vector<pair<float, float>>& NewGraphG_Location, MyTree& NewRtree_G, priority_queue<DistanceAndVertex>& NecessaryVertices
    , vector<DistanceAndVertex>& AllVertices, OverloadedSearch& overloadedSearch)
{
    vector<unsigned> Connect;
    ConnectedGraphNonCandidateGk(k, nq, ExL_Degree, SubGraph, Connect);
    float&& rcur = MinimumExternalCirclePrecision(Connect, NewGraphG_Location);

    vector<vector<unsigned>> subgraph;
    while (!NecessaryVertices.empty())
    {
        int nv1 = NecessaryVertices.top().id;
        NecessaryVertices.pop();
        /**/
        if (ExL_Degree[nv1] < k)
        {
            continue;
        }
        float&& MinmalCircleRadius = max(distance(NewGraphG_Location[nv1], NewGraphG_Location[nq]) / 2.0, distance(NewGraphG_Location[nv1], NewGraphG_Location[nm]) / 2.0);
        if (rcur != 65555)
        {
            if (MinmalCircleRadius >= rcur)
            {
                return rcur;
            }
            MinmalCircleRadius = max(MinmalCircleRadius, rcur);
        }
        for (int j = 0; j != AllVertices.size(); ++j)
        {
            int nv2 = AllVertices[j].id;
            float&& d_v12 = distance(NewGraphG_Location[nv1], NewGraphG_Location[nv2]);
            //pruning 
            if (ExL_Degree[nv2] < k || nv2 == nv1 || d_v12 > 2 * rcur || d_v12 < sqrt(3) * MinmalCircleRadius)// 
            {
                continue;
            }
            float&& CircleRadius = d_v12 / 2.0;
            //CircleRadius2 = CircleRadius * CircleRadius;
            pair<float, float>&& CircleCenter = calculateCenter(NewGraphG_Location[nv1].first, NewGraphG_Location[nv1].second,
                NewGraphG_Location[nv2].first, NewGraphG_Location[nv2].second);
            //������Բ���ܰ���q��m���ж��ǲ��Ǵ���һ������Լ���Ľ����������ڣ�����������֤����Ϊ�����ǰ뾶��С�ġ�
            if (distance(CircleCenter, NewGraphG_Location[nq]) <= CircleRadius + 0.0001 && distance(CircleCenter, NewGraphG_Location[nm]) <= CircleRadius + 0.0001)
            {
                overloadedSearch.SearchR_RRefine(CircleCenter, CircleRadius, NewRtree_G, subgraph, CandidateGk, Gk_OldNew, SubGraph, ExL_Degree);
                auto nnq = Gk_OldNew[nq];
                auto nnm = Gk_OldNew[nm];
                if (Rvarify_kcore(nnq, nnm, k, subgraph, L_Degree, bin, pos, vert))
                {
                    if (Rconnected_verifySingleThread(nnq, nnm, k, subgraph, L_Degree))
                    {
                        //rcur = min(rcur, CircleRadius);
                        return rcur = min(rcur, CircleRadius);
                        //break;
                    }
                }
            }
            for (int l = j + 1; l != AllVertices.size(); ++l)
            {
                int nv3 = AllVertices[l].id;
                float&& d_v13 = distance(NewGraphG_Location[nv1], NewGraphG_Location[nv3]);
                float&& d_v23 = distance(NewGraphG_Location[nv2], NewGraphG_Location[nv3]);
                //����|v1,v2|�����
                if (ExL_Degree[nv3] < k || nv3 == nv1 || d_v13 > d_v12 || d_v23 > d_v12)// 
                {
                    continue;
                }
                if (largest_angle(NewGraphG_Location[nv1], NewGraphG_Location[nv2], NewGraphG_Location[nv3]))
                {
                    //���������
                    CircleCenter = calculateCenter(NewGraphG_Location[nv1].first, NewGraphG_Location[nv1].second,
                        NewGraphG_Location[nv2].first, NewGraphG_Location[nv2].second,
                        NewGraphG_Location[nv3].first, NewGraphG_Location[nv3].second, CircleRadius);
                    //�������������Բ����q��m
                    if (distance(CircleCenter, NewGraphG_Location[nq]) <= CircleRadius - 0.00001 && distance(CircleCenter, NewGraphG_Location[nm]) <= CircleRadius - 0.00001)
                    {

                        overloadedSearch.SearchR_RRefine(CircleCenter, CircleRadius, NewRtree_G, subgraph, CandidateGk, Gk_OldNew, SubGraph, ExL_Degree);
                        auto nnq = Gk_OldNew[nq];
                        auto nnm = Gk_OldNew[nm];
                        if (Rvarify_kcore(nnq, nnm, k, subgraph, L_Degree, bin, pos, vert))
                        {
                            if (Rconnected_verifySingleThread(nnq, nnm, k, subgraph, L_Degree))
                            {
                                rcur = min(rcur, CircleRadius);
                                //return rcur = CircleRadius;
                                //rcur = CircleRadius;
                                break;
                            }
                        }
                    }
                }
            }
        }

    }
    return rcur;
}

float R_RefineRPlus::BestRefinationRWithIndex(int k, int nq, int nm, vector<vector<unsigned>>& SubGraph, vector<int>& ExL_Degree,
    const vector<pair<float, float>>& NewGraphG_Location, MyTree& NewRtree_G, priority_queue<DistanceAndVertex>& NecessaryVertices
    , vector<DistanceAndVertex>& AllVertices, OverloadedSearch& overloadedSearch, vector<vector<int> >& AfterProLeverCoreness)
{
    vector<unsigned> Connect;
    ConnectedGraphNonCandidateGk(k, nq, ExL_Degree, SubGraph, Connect);
    float&& rcur = MinimumExternalCirclePrecision(Connect, NewGraphG_Location);

    vector<vector<unsigned>> subgraph;

    auto start = std::chrono::high_resolution_clock::now();

    while (!NecessaryVertices.empty())
    {
        auto end = std::chrono::high_resolution_clock::now();
        //end - start   ms
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
        //time out
        if (duration.count() > 100000)
        {
            cout << "time out JustR" << endl;
            return rcur;
        }

        int nv1 = NecessaryVertices.top().id;
        NecessaryVertices.pop();
        /**/
        if (ExL_Degree[nv1] < k)
        {
            continue;
        }
        float&& MinmalCircleRadius = max(distance(NewGraphG_Location[nv1], NewGraphG_Location[nq]) / 2.0, distance(NewGraphG_Location[nv1], NewGraphG_Location[nm]) / 2.0);
        if (rcur != 65555)
        {
            if (MinmalCircleRadius >= rcur)
            {
                return rcur;
            }
            MinmalCircleRadius = max(MinmalCircleRadius, rcur);
        }
        for (int j = 0; j != AllVertices.size(); ++j)
        {
            int nv2 = AllVertices[j].id;
            float&& d_v12 = distance(NewGraphG_Location[nv1], NewGraphG_Location[nv2]);
            //pruning 
            if (ExL_Degree[nv2] < k || nv2 == nv1  || d_v12 > 2 * rcur || d_v12 < sqrt(3) * MinmalCircleRadius)// 
            {
                continue;
            }
            float&& CircleRadius = d_v12 / 2.0;
            //CircleRadius2 = CircleRadius * CircleRadius;
            pair<float,float>&& CircleCenter = calculateCenter(NewGraphG_Location[nv1].first, NewGraphG_Location[nv1].second,
                NewGraphG_Location[nv2].first, NewGraphG_Location[nv2].second);
            //������Բ���ܰ���q��m���ж��ǲ��Ǵ���һ������Լ���Ľ����������ڣ�����������֤����Ϊ�����ǰ뾶��С�ġ�
            if (distance(CircleCenter, NewGraphG_Location[nq]) <= CircleRadius + 0.00001 && distance(CircleCenter, NewGraphG_Location[nm]) <= CircleRadius + 0.00001)
            {
                //cout << "Circle searches size is:" << overloadsearch.SearchR_Refr(CircleCenter, CircleRadius, NewRtree_G, CandidateGk) << endl;
                if (overloadedSearch.SearchR_RRefineWithIndex(nq, nm, CircleCenter, CircleRadius, NewRtree_G, subgraph, CandidateGk, Gk_OldNew, SubGraph, ExL_Degree,
                    AfterProLeverCoreness) != 0)
                {
                    auto nnq = Gk_OldNew[nq];
                    auto nnm = Gk_OldNew[nm];
                    if (Rvarify_kcore(nnq, nnm, k, subgraph, L_Degree, bin, pos, vert))
                    {
                        if (Rconnected_verifySingleThread(nnq, nnm, k, subgraph, L_Degree))
                        {
                            //rcur = min(rcur, CircleRadius);
                            return rcur = CircleRadius;
                            //break;
                        }
                    }
                }
            }
            for (int l = j + 1; l != AllVertices.size(); ++l)
            {
                int nv3 = AllVertices[l].id;
                float&& d_v13 = distance(NewGraphG_Location[nv1], NewGraphG_Location[nv3]);
                float&& d_v23 = distance(NewGraphG_Location[nv2], NewGraphG_Location[nv3]);
                //����|v1,v2|�����
                if (ExL_Degree[nv3] < k || nv3 == nv1 || d_v13 > d_v12 || d_v23 > d_v12)// 
                {
                    continue;
                }
                if (largest_angle(NewGraphG_Location[nv1], NewGraphG_Location[nv2], NewGraphG_Location[nv3]))
                {
                    //���������
                    CircleCenter = calculateCenter(NewGraphG_Location[nv1].first, NewGraphG_Location[nv1].second,
                        NewGraphG_Location[nv2].first, NewGraphG_Location[nv2].second,
                        NewGraphG_Location[nv3].first, NewGraphG_Location[nv3].second, CircleRadius);

                    if (CircleRadius > rcur)
                    {
                        continue;
                    }
                    //�������������Բ����q��m
                    if (distance(CircleCenter, NewGraphG_Location[nq]) <= CircleRadius + 0.000001 && distance(CircleCenter, NewGraphG_Location[nm]) <= CircleRadius + 0.000001)
                    {
                        if (overloadedSearch.SearchR_RRefineWithIndex(nq, nm, CircleCenter, CircleRadius, NewRtree_G, subgraph, CandidateGk, Gk_OldNew, SubGraph, ExL_Degree,
                            AfterProLeverCoreness) != 0)
                        {
                            auto nnq = Gk_OldNew[nq];
                            auto nnm = Gk_OldNew[nm];
                            if (Rvarify_kcore(nnq, nnm, k, subgraph, L_Degree, bin, pos, vert))
                            {
                                if (Rconnected_verifySingleThread(nnq, nnm, k, subgraph, L_Degree))
                                {
                                    rcur = CircleRadius;
                                    //return rcur = CircleRadius;
                                    //rcur = CircleRadius;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

    }
    return rcur;
}


bool largest_angle(pair<float, float> p1, pair<float, float> p2, pair<float, float> p3)
{
    /*�����������Ϊ��������� ����true
    ���򷵻�false*/
    float&& a = hypot(p2.first - p3.first, p2.second - p3.second);
    float&& b = hypot(p1.first - p3.first, p1.second - p3.second);
    float&& c = hypot(p1.first - p2.first, p1.second - p2.second);
    if (c > a && c > b) {
        swap(c, a);
    }
    else if (b > a && b > c) {
        swap(b, a);
    }
    float&& angle = acos((b * b + c * c - a * a) / (2 * b * c));
    if (angle >= PIs)
    {
        return false;
    }
    return true;
    /*double angle_a = acos((b * b + c * c - a * a) / (2 * b * c));
    double angle_b = acos((a * a + c * c - b * b) / (2 * a * c));
    double angle_c = acos((a * a + b * b - c * c) / (2 * a * b));
    double largest_angle = max(angle_a, max(angle_b, angle_c));
    return angle * 180 / M_PI;//#define _USE_MATH_DEFINES */
}

inline pair<float, float> calculateCenter(const float& x1, const float& y1, const float& x2, const float& y2, const float& x3, const float& y3, float& radius)
{
    float&& a = x1 - x2;
    float&& b = y1 - y2;
    float&& c = x1 - x3;
    float&& d = y1 - y3;
    float&& e = ((x1 * x1 - x2 * x2) - (y2 * y2 - y1 * y1)) / 2;
    float&& f = ((x1 * x1 - x3 * x3) - (y3 * y3 - y1 * y1)) / 2;
    // Բ��λ�� 
    float&& center_x = (e * d - b * f) / (a * d - b * c);
    float&& center_y = (a * f - e * c) / (a * d - b * c);
    radius = std::move(sqrt(pow(center_x - x1, 2) + pow(center_y - y1, 2)));

    return std::move(make_pair(center_x, center_y));
}

inline pair<float, float> calculateCenter(float x1, float y1, float x2, float y2)
{
    return std::move(make_pair((x1 + x2) / 2.0, (y1 + y2) / 2.0));
}

void ConnectedGraphGet(unsigned k, unsigned q, vector<int>& L_Degree, const vector<vector<unsigned>>& Gx, vector<unsigned>& Connect)
{
    Connect.clear();
    vector<unsigned> FindOrNot(L_Degree.size(), false);
    vector<unsigned> WaitToFind;
    WaitToFind.reserve(Gx.size());
    WaitToFind.push_back(q);
    FindOrNot[q] = true;
    while (!WaitToFind.empty())
    {
        unsigned&& temp = std::move(WaitToFind.back());
        WaitToFind.pop_back();
        Connect.push_back(CandidateGk[temp]);
        for (auto& nei : Gx[temp])
        {
            if (FindOrNot[nei] == false)
            {
                FindOrNot[nei] = true;
                if (L_Degree[nei] >= k)
                {
                    WaitToFind.push_back(nei);
                }
            }
        }
    }

}

void ConnectedGraphNonCandidateGk(unsigned k, unsigned q, vector<int>& L_Degree, const vector<vector<unsigned>>& Gx, vector<unsigned>& Connect)
{
    Connect.clear();
    vector<unsigned> FindOrNot(L_Degree.size(), false);
    vector<unsigned> WaitToFind;
    WaitToFind.reserve(Gx.size());
    WaitToFind.push_back(q);
    FindOrNot[q] = true;
    while (!WaitToFind.empty())
    {
        unsigned&& temp = std::move(WaitToFind.back());
        WaitToFind.pop_back();
        Connect.push_back(temp);
        for (auto& nei : Gx[temp])
        {
            if (FindOrNot[nei] == false)
            {
                FindOrNot[nei] = true;
                if (L_Degree[nei] >= k)
                {
                    WaitToFind.push_back(nei);
                }
            }
        }
    }

}